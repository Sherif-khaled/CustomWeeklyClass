<p><img src='<?php echo $image ?>' class='wcs-single__image'></p>
