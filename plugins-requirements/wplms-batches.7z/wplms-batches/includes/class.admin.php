<?php
/**
 * Admin settings for Wplms Batches
 *
 * @class       Wplms_Batches_Admin
 * @author      VibeThemes
 * @category    Admin
 * @package     wplms-batches/includes
 * @version     1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


class Wplms_Batches_Admin{


	public static $instance;
	
	public static function init(){

        if ( is_null( self::$instance ) )
            self::$instance = new Wplms_Batches_Admin();
        return self::$instance;
    }

	private function __construct(){

		add_action('admin_notices',array($this,'check_activate'));
		add_filter('wplms_course_metabox',array($this,'course_metabox'));
		add_filter('wplms_course_creation_tabs',array($this,'course_batch_enrollment'));
	}

	function check_activate(){
		global $bp;
		if(function_exists('bp_is_active')){
			if(!bp_is_active('groups')){
				$message = __('Please activate Groups component in BuddyPress','wplms-batches');
	            echo '<div class="error" style="position:relative;width:90%;"><p>'.$message.'</p></div>'; 
			}
		}else{
			$message = __('Please activate BuddyPress','wplms-batches');
            echo '<div class="error" style="position:relative;width:90%;"><p>'.$message.'</p></div>'; 
		}
	}

	function course_metabox($metabox){
		$metabox['vibe_force_batch_enrolment']=array( // Single checkbox
			'label'	=> __('Force Batch enrollment','vibe-customtypes'), // <label>
			'desc'	=> __('Students must be enrolled in a Batch to pursue this course','vibe-customtypes'), // description
			'id'	=> 'vibe_force_batch_enrolment', // field id and name
			'type'	=> 'showhide', // type of field
	        'options' => array(
	          array('value' => 'H',
	                'label' =>'Hide'),
	          array('value' => 'S',
	                'label' =>'Show'),
	        ),
            'std'   => 'S'
	    );
	     $metabox['vibe_batch_display']=array( // Single checkbox
			'label'	=> __('Batch Display','vibe-customtypes'), // <label>
			'desc'	=> __('Batch Display Style','vibe-customtypes'), // description
			'id'	=> 'vibe_batch_display', // field id and name
			'type'	=> 'select', // type of field
	        'options' => array(
	          array('value' => '',
	                'label' =>'Default (BIG)'),
	          array('value' => 'grid_2',
	                'label' =>'Grid x2'),
	          array('value' => 'grid_3',
	                'label' =>'Grid x3'),
	          array('value' => 'list',
	                'label' =>'List'),
	          array('value' => 'hide',
	                'label' =>'Hide'),
	        ),
            'std'   => ''
	    );
		return $metabox;
	}

	function course_batch_enrollment($settings){
		$arr=array(array( // Text Input
           'label' => __('Force Batch enrollment','wplms-batches'), // <label>
           'text' 	=> __('Students must be enrolled in a Batch to pursue this course','wplms-batches'),
           'desc'  => __('Students must be enrolled in a Batch to pursue this course','wplms-batches'), // description
		   'options'  => array('H'=>__('NO','wplms-batches' ),'S'=>__('YES','wplms-batches' )),
		   'type'=>'switch',
           'from'=> 'meta',
           'id'    => 'vibe_force_batch_enrolment',
           'default'=> 'H',
           ),
		array( // Text Input
           'label' => __('Batch Display','wplms-batches'), // <label>
           'text' 	=> __('Batch display style','wplms-batches'),
           'desc'  => __('Select batch display style on course home page','wplms-batches'), // description
		   'options'  => array(
		   		array('value' => '',
	                'label' => __('Default','wplms-batches')),
	          	array('value' => 'grid_2',
	                'label' =>__('2 Column Grid','wplms-batches')),
	          	array('value' => 'grid_3',
	                'label' => __('3 Column Grid','wplms-batches')),
	          	array('value' => 'list',
	                'label' => __('List Style','wplms-batches')),
	          	array('value' => 'hide',
	                'label' => __('Hide','wplms-batches')),
		   	),
		   'type'=>'select',
           'from'=> 'meta',
           'id'    => 'vibe_batch_display',
           'default'=> 'H',
           ));
 
	  $fields = $settings['course_settings']['fields'];
	 
	  array_splice($fields, 3, 0,$arr );
	 
	  $settings['course_settings']['fields'] = $fields;
		return $settings;
	}
}

Wplms_Batches_Admin::init();