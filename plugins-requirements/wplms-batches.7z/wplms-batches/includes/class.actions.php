<?php
/**
 * Initialise WPLMS Batches
 *
 * @class       Wplms_Batches_Actions
 * @author      VibeThemes
 * @category    Admin
 * @package     WPLMS-Batches/includes
 * @version     1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


class Wplms_Batches_Actions{


	public static $instance;
	
	public static function init(){

        if ( is_null( self::$instance ) )
            self::$instance = new Wplms_Batches_Actions();
        return self::$instance;
    }

	private function __construct(){
		add_action('groups_join_group',array($this,'add_user_to_course'),10,2);
		add_action('groups_leave_group',array($this,'remove_from_batch_course'),10,2);

		add_action('wp_ajax_enroll_user_to_course_batch',array($this,'enroll_user_to_batch'));
		add_action('wplms_course_before_front_main',array($this,'enroll_error_message'));

		//Start Course errors
		add_action('wplms_before_start_course',array($this,'enroll_error'));

		add_action('wplms_tips_default',array($this,'enable_batch_course_visibility_switch'),10,1);

		add_action('bp_activity_post_form_options',array($this,'batch_news'));
		add_action( 'bp_groups_posted_update', array($this,'group_news'),10,4);

		add_action('wplms_the_course_button',array($this,'force_enroll_when_enabled'),10,2);

	}

	function force_enroll_when_enabled($course_id,$user_id){
		
		$force_batch_enrolment = get_post_meta($course_id,'vibe_force_batch_enrolment',true);
		if(!empty($force_batch_enrolment) && $force_batch_enrolment == 'S'){
			
			$taken = bp_course_get_user_course_status($user_id,$course_id);
			if(!empty($taken))
				return;

			$batch_ids = wplms_get_course_batches($course_id);
			if(!empty($batch_ids)){
				foreach($batch_ids as $batch_id){
					if(groups_is_user_member( $user_id, $batch_id)){
						bp_course_add_user_to_course($user_id,$course_id);
						return;
					}
				}
			}
		}
	}


	function group_news($content, $user_id, $group_id, $activity_id ){
		if(is_wplms_batch($group_id)){
			$str = _e('News','wplms-batches').' :';
			if(strpos($content,$str) !== false){
				bp_activity_update_meta($activity_id,'group_news',1);	
			}
		}
	}

	function batch_news(){
		if(!is_user_logged_in())
			return;

		$user_id  = get_current_user_ID();
		global $bp;
		if(bp_is_group_activity() && is_wplms_batch($bp->groups->current_group->id) &&  groups_is_user_mod($user_id,$bp->groups->current_group->id) ||groups_is_user_admin($user_id,$bp->groups->current_group->id)){
			?>
			<div class="checkbox" style="display:inline-block;">
				<input type="checkbox" id="group_news" />
				<label for="group_news"><?php _e('News','wplms-batches'); ?></label>
			</div>
			<script>
			jQuery(document).ready(function($){
				$('#group_news').on('click',function(){
					var val = $('#whats-new').val();
					var str = $.trim($(this).parent().text());
					var patt = new RegExp(str+' :');
					if (patt.test(val)){
						str=str+' :';
					 	val = val.replace(str,'');
					}else{
						val = str+' :'+val;
					}
					$('#whats-new').val(val);
				});
				$('#whats-new').on('mouseup',function(){
					var val = $('#whats-new').val();
					var str = $.trim($(this).parent().text());
					var patt = new RegExp(str+' :');
					if (patt.test(val)){
					 	$('#group_news').prop('checked', true);
					}else{
						$('#group_news').prop('checked', false);
					}
				});
			});
			</script>
			<?php
		}
	}
	function enable_batch_course_visibility_switch($key){
		if($key == 'enable_batch_course_visibility_switch'){
			add_filter('wplms_batches_enable_batch_course_visibility_switch',array($this,'wplms_batches_enable_batch_course_visibility_switch'));
		}
		if($key == 'enable_batch_course_auto_susbcribe'){
			add_filter('wplms_auto_subscribe',array($this,'batch_course_auto_subscribe'),10,2);
		}
	}

	function wplms_batches_enable_batch_course_visibility_switch($flag){
		return 1;
	}

	function batch_course_auto_subscribe($auto_subscribe,$course_id){
		if(!is_user_logged_in())
			return $auto_subscribe;

		$user_id = get_current_user_id();
		$coursetaken = bp_course_get_user_expiry_time($user_id,$course_id);
		if(empty($coursetaken)){
			$batches = wplms_get_course_batches($course_id);
			if(!empty($batches)){
				$batch_list = implode(',',$batches);
				global $wpdb,$bp;
				$result = $wpdb->get_var("SELECT count(group_id) FROM {$bp->groups->table_name_members} WHERE user_id = $user_id AND group_id IN ($batch_list)");
				if(!empty($result)){ // Means user is subscribed to at least one course batch
					return 1;
				}
			}
		}

		return $auto_subscribe;
	}

	function enroll_error(){
		if(isset($_POST['course_id'])){
		    $course_id=$_POST['course_id'];
		}else if(isset($_COOKIE['course'])){
		      $course_id=$_COOKIE['course'];
		}
		if(!empty($course_id)){
			$user_id = get_current_user_ID();

			$batches = wplms_get_course_batches($course_id);
			if(!empty($batches)){
				$user_id = get_current_user_ID();
				foreach($batches as $batch_id){

					if(wplms_batch_is_user_member( $user_id, $batch_id )){
						$return = wplms_batch_timing_accessibility($batch_id,$course_id);
						if(!$return['return']){
							$link = get_permalink($course_id).'?error=unavailable&batch='.$batch_id.'&message='.urlencode($return['message']);
							wp_redirect($link);
							exit;
						}
						break;
					}
				}
			}
			
		}

	}
	function enroll_error_message(){
		if(isset($_REQUEST['error']) && $_REQUEST['error'] == 'enroll'){ 
			 echo '<div id="message" class="notice"><p>'.__('Enroll in a batch to start the course. ','wplms-batches').'</p></div>';
 		}
 		if(isset($_REQUEST['error']) && $_REQUEST['error'] == 'unavailable'){ 
 			global $post;

 			if(is_numeric($_GET['batch']) && wplms_course_batch_verify($post->ID,$_GET['batch']))
			 echo '<div id="message" class="notice"><p>'.urldecode($_GET['message']).'</p></div>';
 		}
	}

	function enroll_user_to_batch(){

      	$course_id = $_POST['course_id'];
      	$batch_id = $_POST['batch'];
      	$user_id = get_current_user_ID();


      	if ( !isset($_POST['security']) || !wp_verify_nonce($_POST['security'],'enroll_now'.$batch_id.$user_id) || !is_numeric($course_id) || !is_numeric($batch_id)){

         	_e('Security check Failed. Contact Administrator.','vibe');
         	die();
      	}

      	if(bp_course_is_member($course_id,$user_id) && wplms_course_batch_verify($course_id,$batch_id)){
      		groups_join_group($batch_id, $user_id ); 
      		echo $batch_id; //Numeric value
      	}else{
      		_e('User not in course','wplms-batches');
      	}

      	die();
	}

	function add_user_to_course($group_id,$user_id){
		if(is_wplms_batch($group_id)){
			$course_ids = get_batch_courses($group_id);
			if(!empty($course_ids)){
				$enable_batch_duration = groups_get_groupmeta($group_id,'enable_batch_duration');
			
				if(!empty($enable_batch_duration)){
					$batch_duration = groups_get_groupmeta($group_id,'batch_duration');
					$batch_duration_parameter = groups_get_groupmeta($group_id,'batch_duration_parameter');
					$batch_duration_parameter = wplms_process_batch_duration($batch_duration_parameter);
					$t = $batch_duration*$batch_duration_parameter;
				}
				
				foreach($course_ids as $course_id){
					if(function_exists('bp_course_is_member') && !bp_course_is_member($course_id,$user_id)){
						if(!empty($enable_batch_duration)){
							bp_course_add_user_to_course($user_id,$course_id,$t,1);
						}else{
							bp_course_add_user_to_course($user_id,$course_id);
						}
						
					}
				}
			}
		}
	}

	function remove_from_batch_course($group_id,$user_id){

		if(is_wplms_batch($group_id)){
			$course_ids = get_batch_courses($group_id);
			if(!empty($course_ids)){
				foreach($course_ids as $course_id){
					if(function_exists('bp_course_is_member') && bp_course_is_member($course_id,$user_id)){
						bp_course_remove_user_from_course($user_id,$course_id);
					}
				}
			}
		}
	}

}

Wplms_Batches_Actions::init();