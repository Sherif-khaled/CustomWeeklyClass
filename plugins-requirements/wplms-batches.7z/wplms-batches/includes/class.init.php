<?php
/**
 * Initialise WPLMS Batches
 *
 * @class       Wplms_Batches_Init
 * @author      VibeThemes
 * @category    Admin
 * @package     WPLMS-Batches/includes
 * @version     1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action('bp_include','wplms_batches_load_init_scripts');
function wplms_batches_load_init_scripts(){
	include_once 'batches/batches.php';
	include_once 'batches/create.php';
	include_once 'batches/statistics.php';
}


class Wplms_Batches_Init{


	public static $instance;
	
	public static function init(){

        if ( is_null( self::$instance ) )
            self::$instance = new Wplms_Batches_Init();
        return self::$instance;
    }

	private function __construct(){

		add_action('init',array($this,'remove_actions'));

		add_action('wp_enqueue_scripts',array($this,'register_scripts'));


		add_action('bp_directory_groups_actions',array($this,'bp_group_is_batch'),99);

		//Show Batch information in Course
		add_action('wplms_after_course_description',array($this,'wplms_batches'));

		add_action('template_redirect',array($this,'batch_student_assign_to_course'));
		
		add_action('wp_ajax_add_to_course_batch',array($this,'add_to_course_batch'));
		add_action('wplms_course_unsubscribe',array($this,'remove_from_batch'),10,2);
		add_filter('wplms_front_end_event_settings',array($this,'batch_events'),10,2);
		add_filter('eventon_event_metaboxs',array($this,'batch_event_fields'),20);
		add_filter('eventon_event_metafields',array($this,'save_batch_event_fields'));
		add_action('bp_before_group_description',array($this,'batch_details'));

		//add_action('wplms_course_review',array($this,'wplms_batch_rating'),10,2);
	}

	function remove_actions(){
		remove_action('bp_group_options_nav','vibe_course_group_link',1,1);
	}

	function register_scripts(){
		global $post,$bp;

		if( (is_singular('course') && wplms_course_has_batches($post->ID)) || is_wplms_batch($bp->groups->current_group->id)){
			wp_enqueue_style( 'wplms-batches', plugins_url('../assets/css/batches.css',__FILE__));
			wp_enqueue_script( 'wplms-batches', plugins_url('../assets/js/batches.js',__FILE__), array('jquery'), 1.0, true );
			$translation_array = array( 
				'enroll_warning' => _x( 'Are you sure you want to enroll into this batch ?','Enroll into batch popup message.','wplms-batches' ), 
				'enrolled'=>_x('Enrolled','enrolled label','wplms-batches'),
				'fetching'=>_x('Calculating stats...','calculating stats for course','wplms-batches'),
			);
			wp_localize_script( 'wplms-batches', 'wplms_batches', $translation_array );
		}
	}

	function bp_group_is_batch(){
		$group_id = bp_get_group_id();
		if(is_wplms_batch($group_id)){
			$course_ids = get_batch_courses($group_id);
			if(!empty($course_ids)){
				echo '<div class="batch_courses clear">';
				foreach($course_ids as $course_id){
					echo '<a href="'.get_permalink($course_id).'" title="'.get_the_title($course_id).'" class="batch_course">'.get_the_post_thumbnail($course_id,'mini').'</a>';
				}
				echo '</div>';
			}
		}
	}


	function get_course_batch_details($group_id){


			$enable = groups_get_groupmeta( $group_id, 'course_batch' );
			if(empty($enable)){
				return;
			}

            $courses = groups_get_groupmeta($group_id,'batch_course',false);
            if(empty($courses)){
            	return __('No course found in batch','wplms-batches');
            }
            
            
			return $this->batch_details;
	}


	function wplms_batches(){
		$course_id = get_the_ID();

		$display_style = get_post_meta($course_id,'vibe_batch_display',true);

		if(!empty($display_style) && $display_style == 'hide')
			return;

		global $wpdb,$bp;
		
		$batches = wplms_get_course_batches($course_id);
		
		if(empty($batches))
			return;

		$this->show_enroll_button = 0;

		if(!empty($batches) && is_array($batches) && count($batches)){

			$this->n = count($batches)-1;
			if(is_user_logged_in()){
				$user_id =get_current_user_ID();
				if(bp_course_is_member($course_id,$user_id)){
					$this->show_enroll_button = 1;
					foreach($batches as $k => $batch_id){
						if(wplms_batch_is_user_member( $user_id, $batch_id )){
							$this->show_enroll_button = 0;
							break;
						}
					}
				}
			}

			if(!empty($member_batch)){
				unset($batches[$mb_k]);
				array_unshift($batches,$member_batch);
			}
			if(!empty($display_style) && ($display_style == 'grid_2' || $display_style == 'grid_3')){$grid_flag = 1;}
			?>
			<div class="course_batches<?php echo (!empty($grid_flag)?'_grid':''); ?>"><h3 class="heading"><span><?php _e('Course Batches','wplms-batches')?></span></h3><ul <?php echo (!empty($grid_flag)?'class="row"':''); ?>>
			<?php	
			
			foreach($batches as $k=> $batch_id){

				$this->batch_snapshot($batch_id,$display_style);
					
			} ?>
			</ul>
			<?php
			echo '<input type="hidden" id="batch_course_id" value="'.get_the_ID().'" />';
			?>
			</div>
			<?php
		}
	}	

	function batch_student_assign_to_course(){

		if(is_singular('course') && is_user_logged_in()){
			$course_id = get_the_ID();
			$user_id = get_current_user_ID();
			$batches = wplms_get_course_batches($course_id);
			if(!empty($batches) && is_array($batches) && count($batches)){
				foreach($batches as $k => $batch_id){
					if(wplms_batch_is_user_member( $user_id, $batch_id)){
						$course_user= bp_course_get_user_course_status($user_id,$course_id);
						if(empty($course_user))
							bp_course_add_user_to_course($user_id,$course_id);
						break;
					}
				}
			}
		}
	}

	function add_to_course_batch(){
		$batch_id = $_POST['id'];
		$course_id = $_POST['course_id'];
		$security = vibe_get_option('security_key');
		if ( !isset($_POST['security']) || !wp_verify_nonce($_POST['security'],$security) ){
		    _e('Security check Failed. Contact Administrator.','vibe');
		    die();
		}
		$user_id = get_current_user_ID();
		$course_batch = groups_get_groupmeta($batch_id,'batch_course');
		if($course_id == $course_batch){
			groups_join_group($batch_id, $user_id );  	
			echo 1;
		}else{
			_e('Unable to allocate to batch','wplms-batches');
		}
		
		die();  
	}

	function remove_from_batch($course_id,$user_id){
		global $wpdb,$bp;
		$batches = $wpdb->get_results($wpdb->prepare("SELECT group_id FROM {$bp->groups->table_name_members} WHERE user_id = %d AND group_id IN (SELECT group_id FROM {$bp->groups->table_name_groupmeta} WHERE meta_key = %s AND meta_value = %d )",$user_id,'batch_course',$course_id));
		if(!empty($batches)){
			foreach($batches as $batch){
				groups_leave_group( $batch->group_id, $user_id );
			}
		}
		return;
	}


	function get_batch_name($batch_id){
		global $wpdb,$bp;
		$batch_name = $wpdb->get_results($wpdb->prepare("SELECT name FROM {$bp->groups->table_name} WHERE id = %d",$batch_id));
		if(!empty($batch_name))
			return $batch_name->name;
		else
			return '';
	}

	function get_batch_names($batches){
		$batch_ids = '';
		foreach($batches as $k=> $batch){
			if(!empty($k))
				$batch_ids .=',';
			if(is_numeric($batch)){
				$batch_ids .= $batch;
			}else if(is_numeric($batch->group_id)){
				$batch_ids .= $batch->group_id;
			}
		}

		global $wpdb,$bp;
		$batch_names = $wpdb->get_results("SELECT id,name FROM {$bp->groups->table_name} WHERE id IN ($batch_ids)");
		return $batch_names;
	}

	function get_all_batches($course_id = null){
		global $wpdb,$bp;
		if(empty($course_id)){
			$q = $wpdb->prepare("SELECT g.id as id,g.name as name FROM {$bp->groups->table_name} as g LEFT JOIN {$bp->groups->table_name_groupmeta} as m ON g.id = m.group_id WHERE m.meta_key = %s AND m.meta_value = %d",'course_batch',1);
		}else{
			$q = $wpdb->prepare("SELECT g.id as id,g.name as name FROM {$bp->groups->table_name} WHERE id IN ( SELECT group_id FROM {$bp->groups->table_name_groupmeta} as m1 LEFT JOIN {$bp->groups->table_name_groupmeta} as m2 ON  m1.group_id = m2.group_id WHERE m1.meta_key = %s AND m2.meta_key = %s AND m1.meta_value = %d AND m2.meta_value = %d",'course_batch','batch_course',1,$course_id);
		}

		$batches = $wpdb->get_results($q);
		return $batches;
	}


	function get_batch_list(){
		// HTML - User Interaction
		ob_start();
		?>
			<div class='evcal_data_block_style1'>
				<p class='edb_icon evcal_edb_map'></p>
				<div class='evcal_db_data'>			
					<p>
					<?php
						// organier terms for event post
						$batches = self::get_all_batches();
						global $post;
						$wplms_ev_batch = get_post_meta($post->ID,'wplms_ev_batch',true);
						if(count($batches) > 0){
							echo "<select id='wplms_ev_batch' name='wplms_ev_batch' class='chosen'>
								<option value=''>".__('Select a WPLMS Course Batch','wplms-batches')."</option>";
						    foreach ( $batches as $batch ) {
						       	echo "<option value='". $batch->id ."' ".( ($wplms_ev_batch == $batch->id )?"selected='selected'":"" ).">" . $batch->name . "</option>";						        
						    }
						    echo "</select> <label for='evcal_organizer_field'>".__('Choose a course batches','wplms-batches')."</label><style>.chosen-container .chosen-results li.active-result{color:#444;}</style>";
						}

					
					?>
					<p style='clear:both'></p>
				</div>
			</div>
		<?php
		$_html = ob_get_clean();
		return $_html; 
	}


	function batch_events($fields,$course_id){
		$batches = '';
		$options=array('label'=>__('None','wplms-batches'),'value'=>'');
		if(!empty($_POST['element_id'])){
			$event_id = $_POST['element_id'];
			$batches = wplms_get_course_batches($course_id);
			if(!empty($batches)){
				$batch_names = self::get_batch_names($batches);
				foreach($batch_names as $batch){
					$options[]=array('value'=>$batch->id,'label'=>$batch->name);
				}
			}
		}


		$fields[] = array( // Single checkbox
						'label'	=> __('Course Batch','vibe-customtypes'), // <label>
						'desc'	=> __('Connect a Course batch to this event','vibe-customtypes'), // description
						'id'	=> 'wplms_ev_batch', // field id and name
						'type'	=> 'select', // type of field
						'options' => $options,
						'value' => get_post_meta($event_id,'wplms_ev_batch',true),
				        'std'   => ''
	                );
		return $fields;
	}

	function batch_event_fields($metabox){
		$metabox[]=array(
				'id'=>'wplms_ev_batch',
				'name'=>__('WPLMS Course Batch','wplms-batches'),
				'variation'=>'customfield',		
				'iconURL'=>'fa-book',
				'iconPOS'=>'',
				'type'=>'code',
				'content'=> self::get_batch_list(),
				'slug'=>'ev_subtitle'
			);
		return $metabox;
	}

	function save_batch_event_fields($fields){
		$fields[] = 'wplms_ev_batch';
		return $fields;
	}

	// USED IN BATCH
	function batch_details(){

		$group_id = bp_get_group_id();

		if(is_wplms_batch($group_id)){
			$course_ids = get_batch_courses($group_id);
			if(!empty($course_ids)){
				$course_ids = array_unique($course_ids);
				echo '<div class="row">';
				echo '<div class="col-md-4"><h3 class="heading"><span>'.__('Courses Included','wplms-batches').'</span></h3>';

					echo '<ul class="batch_home_courses">';
					foreach($course_ids as $course_id){
						echo '<li>'.get_the_post_thumbnail($course_id,'thumbnail');
						echo '<strong><a href="'.get_permalink($course_id).'">'.get_the_title($course_id).'</a></strong>';
						echo '<span>'.get_the_term_list( $course_id, 'course-cat', '', ', ', '' ).'</span>';
						echo '</li>';
					}
					echo '</ul>';
				
				echo '</div><div class="col-md-4"><h3 class="heading"><span>'.__('Batch Details','wplms-batches').'</span></h3>';
				echo '<div class="snapshot">
					<span class="batch_user_count"><label>'.__('MEMBERS','wplms-batches').'</label>';
				$count = groups_get_total_member_count($group_id);	
				$enable_seats = groups_get_groupmeta($group_id,'enable_seats');
			
				echo (empty($count)?1:$count); 
				if(!empty($enable_seats)){
					$batch_seats = groups_get_groupmeta($group_id,'batch_seats');
					echo ' / '.$batch_seats;
				}
				echo '</span>';
								
				if(!empty($enable_seats)){
				echo '<div class="progress" style="width:200px;height:4px;">
					<div class="bar" style="width:'.round((100*$count/$batch_seats),0).'%;"></div>
				</div>';
				}
				$enable_batch_date = groups_get_groupmeta($group_id,'enable_batch_date');
				if(!empty($enable_batch_date)){
					$start_batch_date = groups_get_groupmeta($group_id,'start_batch_date');
					$end_batch_date = groups_get_groupmeta($group_id,'end_batch_date');
					if(!empty($start_batch_date)){
						$start_time = strtotime($start_batch_date);
						echo '<div class="batch_start_date"><label>'.__('STARTS','wplms-batches').'</label><span>'.date_i18n( get_option( 'date_format' ), $start_time ).'</span></div>';
					}
					if(!empty($end_batch_date)){
						$end_time = strtotime($end_batch_date) + 86400;
						if($end_time < current_time('timestamp')){
							$enrol_batch = 0;
						}
						echo '<div class="batch_end_date"><label>'.__('ENDS','wplms-batches').'</label><span>'.date_i18n( get_option( 'date_format' ), $end_time ).'</span></div>';
					}
				}
				$enable_off_schedule =groups_get_groupmeta($group_id,'enable_off_schedule');
				if(!empty($enable_off_schedule)){
					$weekly_off_schedule =groups_get_groupmeta($group_id,'weekly_off_schedule');
					if(!empty($weekly_off_schedule)){
						echo '<div class="weekly_off_schedule"><label>'.__('Weekly Schedule','wplms-batches').'</label>';
						$days = array(
							1=>__('Monday','wplms-batches'),
							2=>__('Tuesday','wplms-batches'),
							3=>__('Wednesday','wplms-batches'),
							4=>__('Thursday','wplms-batches'),
							5=>__('Friday','wplms-batches'),
							6=>__('Saturday','wplms-batches'),
							7=>__('Sunday','wplms-batches'),
						);
						echo '<ul>';
						foreach($days as $k=>$day){
							echo '<li '.(in_array($k,$weekly_off_schedule)?'class="off"':'').'>'.substr($day,0,1).'</li>';
						}
						echo '</ul></div>';
					}
					$monthly_off_schedule =groups_get_groupmeta($group_id,'monthly_off_schedule');
					$annual_off_schedule =groups_get_groupmeta($group_id,'annual_off_schedule');
				}
				echo '</div></div><div class="col-md-4"><h3 class="heading"><span>'.__('Batch News','wplms-batches').'</span></h3>';
				global $wpdb,$bp;			
				$news = $wpdb->get_results($wpdb->prepare("SELECT a.content as news, a.user_id as user_id FROM {$bp->activity->table_name} a LEFT JOIN {$bp->activity->table_name_meta} m ON a.id = m.activity_id WHERE m.meta_key = %s AND a.component = %s AND a.type=%s AND a.item_id=%d ORDER BY a.date_recorded DESC LIMIT 0,10",'group_news','groups','activity_update',$group_id));

				if(empty($news)){
					echo '<div class="message">'.__('No news for this batch !','wplms-batches').'</div>';
				}else{
					echo '<div class="batch_news"><ul class="slides">';

					for($i=0;$i<count($news);$i=$i+3){

						echo '<li>
								<div class="batch_news"><a href="'.bp_core_get_user_domain($news[$i]->user_id).'" class="batch_news_author">';
													echo bp_core_fetch_avatar( array(
											                'item_id' => $news[$i]->user_id,
											                 'type' => 'thumb',
											                 'width'      => '64',
															 'height'     => '64',
											                 ));
								echo '</a>'.$news[$i]->news.'</div>';

								if(isset($news[$i+1]) && !empty($news[$i+1]->news)){
								echo '<div class="batch_news"><a href="'.bp_core_get_user_domain($news[$i+1]->user_id).'" class="batch_news_author">';
													echo bp_core_fetch_avatar( array(
											                'item_id' => $news[$i]->user_id,
											                 'type' => 'thumb',
											                 'width'      => '64',
															 'height'     => '64',
											                 ));
								echo '</a>'.$news[$i+1]->news.'</div>';
							if(isset($news[$i+1]) && !empty($news[$i+2]->news)){
							echo '<div class="batch_news"><a href="'.bp_core_get_user_domain($news[$i+2]->user_id).'" class="batch_news_author">';
												echo bp_core_fetch_avatar( array(
										                'item_id' => $news[$i]->user_id,
										                 'type' => 'thumb',
										                 'width'      => '64',
														 'height'     => '64',
										                 ));
							echo '</a>'.$news[$i+2]->news.'</div>';
							}
						}
						echo '</li>';
					}
					echo '</ul></div>';
				}
				echo '</div></div>';
			}
		}
	}


	function batch_snapshot($batch_id,$display_style=NULL){

		if(!empty($display_style)){
			if($display_style == 'grid_2' || $display_style == 'grid_3'){
				$this->batch_grid_style($display_style,$batch_id);
			}else if($display_style == 'list'){
				$this->batch_list_style($batch_id);
			}
			return;	
		}

		$user_id = get_current_user_ID();
		$batch = groups_get_group( array( 'group_id' => $batch_id ) );
		
		$avatar  = bp_core_fetch_avatar( array(
		'item_id'    => $batch_id,
		'object'     => 'group',
		'type'       => 'thumb',
		'avatar_dir' => 'group-avatars',
		'alt'        => sprintf( __( 'Group logo of %s', 'wplms-batches' ), $batch->name ),
		'width'      => '256',
		'height'     => '256',
		'title'      => $batch->name
		) );
		$group_permalink = trailingslashit( bp_get_root_domain() . '/' . bp_get_groups_root_slug() . '/' . $batch->slug . '/' );
		$enrolled_label='';
		$enroll_flag = 1;
		$member_batch = 0;
		if(wplms_batch_is_user_member( $user_id, $batch_id )){
			$member_batch = 1;
		}
		if(!empty($member_batch)){ 
			$class= 'enrolled';
			$enrolled_label='<span class="enrolled">'.__('enrolled','wplms-batches').'</span>';
		}	

		$count = groups_get_total_member_count($batch_id);
		$enable_seats = groups_get_groupmeta($batch_id,'enable_seats');
		if(!empty($enable_seats)){
			$batch_seats = groups_get_groupmeta($batch_id,'batch_seats');
		}
		if(function_exists('vibe_get_customizer')){
			$layout = vibe_get_customizer('course_layout');
		}

		echo '<li id="batch'.$batch_id.'" class="course_batch '.apply_filters('wplms_course_batch_display_class',$class,$batch_id).'" >';
				?>
					<div class="snapshot">
						<div class="row">
							<div class="<?php echo (empty($layout)?'col-md-6':'col-md-3'); ?>">
								<a href="<?php echo $group_permalink; ?>"><?php echo $avatar; ?></a>
								<div class="labels">
								<?php
								echo $enrolled_label;
								if(!empty($enable_seats)){
									if($count >= $batch_seats){
										$enroll_flag = 0;
										echo '<span class="full">'.__('SEATS FULL','wplms-batches').'</span>';
									}
								}
								?>
								</div>
							</div>
							<div class="col-md-6">
								<h4><a href="<?php echo $group_permalink; ?>"><?php echo $batch->name; ?></a></h4>
								<p><?php echo substr($batch->description,0,80); ?></p>
								<span class="batch_user_count"><label><?php _e('SEATS','wplms-batches'); ?><label>&nbsp;<?php 
								
								echo (empty($count)?1:$count); 
									if(!empty($enable_seats)){
										echo ' / '.$batch_seats;
									}
								?></span>
								<?php
								if(!empty($enable_seats)){
									?>
								<div class="progress" style="width:200px;height:4px;">
									<div class="bar" style="width:<?php echo round((100*$count/$batch_seats),0); ?>%;"></div>
								</div>
								<?php
								}
								?>
								<div class="batch_admins">
								<?php
									if(empty($batch->admins)){
										$admins = array($batch->creator_id);
									}else{
										$admins = $batch->admins;
									}
									foreach($admins as $admin_id){
									?>
										<a href="<?php echo bp_core_get_user_domain($admin_id); ?>" class="batch_admin">
										<?php echo bp_core_fetch_avatar( array(
								                'item_id' => $admin_id,
								                 'type' => 'thumb',
								                 'width'      => '64',
												 'height'     => '64',
								                 ));
								                 ?>
						                 </a>
					                 <?php
					             	}
				                 	?>
			                 	</div>
							</div>
							<div class="<?php echo (empty($layout)?'col-md-6':'col-md-3'); ?>">
							<?php

								$enable_batch_date = groups_get_groupmeta($batch_id,'enable_batch_date');
								if(!empty($enable_batch_date)){
									$start_batch_date = groups_get_groupmeta($batch_id,'start_batch_date');
									$end_batch_date = groups_get_groupmeta($batch_id,'end_batch_date');
									if(!empty($start_batch_date)){
										$start_time = strtotime($start_batch_date);
										echo '<div class="batch_start_date"><label>'.__('STARTS','wplms-batches').'</label><span>'.date_i18n( get_option( 'date_format' ), $start_time ).'</span></div>';
									}
									if(!empty($end_batch_date)){
										$end_time = strtotime($end_batch_date) + 86400;
										
										if($end_time < current_time('timestamp')){
											$enroll_flag = 0;
										}
										echo '<div class="batch_end_date"><label>'.__('ENDS','wplms-batches').'</label><span>'.date_i18n( get_option( 'date_format' ), $end_time ).'</span></div>';
									}
								}
								$batch_timings = groups_get_groupmeta($batch_id,'batch_timings');
								if(!empty($batch_timings)){
									$batch_start_timing = groups_get_groupmeta($batch_id,'batch_start_time');
									$batch_end_timing = groups_get_groupmeta($batch_id,'batch_end_time');
									$batch_repeatable = groups_get_groupmeta($batch_id,'batch_repeatable');
									if(!empty($batch_start_timing[$course_id]) && !empty($batch_end_timing[$course_id])){
										echo '<div class="batch_timing"><label>'.__('TIMINGS','wplms-batches').'</label><span>'.$batch_start_timing[$course_id].' - '.$batch_end_timing[$course_id].'</span>';
										echo '</div>';

									if(!empty($batch_repeatable)){

									
										$batch_repeatable_parameter = groups_get_groupmeta($batch_id,'batch_repeatable_parameter');
										$batch_repeatable_parameter = $batch_repeatable_parameter[$course_id];
										$batch_repeatable = $batch_repeatable[$course_id];
										if(function_exists('calculate_duration_time')){
											$batch_repeatable_parameter = wplms_process_batch_duration($batch_repeatable_parameter);
											$batch_repeatable_parameter = calculate_duration_time($batch_repeatable_parameter);
											$batch_repeatable_parameter = translate($batch_repeatable_parameter,'vibe-customtypes');
										}
										echo '<div class="batch_timing"><label>'.__('Every','wplms-batches').'</label><span>'.$batch_repeatable.' '.$batch_repeatable_parameter.'</span></div>';
									}
									}
								}
								$enable_off_schedule =groups_get_groupmeta($batch_id,'enable_off_schedule');
								if(!empty($enable_off_schedule)){
									echo '<div class="weekly_off_schedule"><label>'.__('Weekly Schedule','wplms-batches').'</label>';
									$weekly_off_schedule =groups_get_groupmeta($batch_id,'weekly_off_schedule');
									if(!empty($weekly_off_schedule)){
										$days = array(
											1=>__('Monday','wplms-batches'),
											2=>__('Tuesday','wplms-batches'),
											3=>__('Wednesday','wplms-batches'),
											4=>__('Thursday','wplms-batches'),
											5=>__('Friday','wplms-batches'),
											6=>__('Saturday','wplms-batches'),
											7=>__('Sunday','wplms-batches'),
										);
										echo '<ul>';
										foreach($days as $k=>$day){
											echo '<li '.(in_array($k,$weekly_off_schedule)?'class="off"':'').'>'.substr($day,0,1).'</li>';
										}
										echo '</ul></div>';
									}
									$monthly_off_schedule =groups_get_groupmeta($batch_id,'monthly_off_schedule');
									$annual_off_schedule =groups_get_groupmeta($batch_id,'annual_off_schedule');
								}

								if($this->show_enroll_button && $enroll_flag){
									echo '<a data-batch="'.$batch_id.'" class="button enroll_in_batch">'.__('Enroll Now','wplms-batches').' &rsaquo;</a>';
									wp_nonce_field('enroll_now'.$batch_id.$user_id,'enroll_now'.$batch_id);
								}
								?>
						</div>
					</div>
				</div>				
			<?php
			echo '</li>';
	}

	function batch_grid_style($grid,$batch_id){
		$enroll_flag = 1;
		$user_id = get_current_user_ID();
		$batch = groups_get_group( array( 'group_id' => $batch_id ) );
		
		$avatar  = bp_core_fetch_avatar( array(
		'item_id'    => $batch_id,
		'object'     => 'group',
		'type'       => 'full',
		'avatar_dir' => 'group-avatars',
		'alt'        => sprintf( __( 'Group logo of %s', 'wplms-batches' ), $batch->name ),
		'width'      => '460',
		'height'     => '460',
		'title'      => $batch->name
		) );
		$group_permalink = trailingslashit( bp_get_root_domain() . '/' . bp_get_groups_root_slug() . '/' . $batch->slug . '/' );
		$enrolled_label='';
		$member_batch = 0;
		if(wplms_batch_is_user_member( $user_id, $batch_id )){
			$member_batch = 1;
		}
		if(!empty($member_batch)){ 
			$enroll_flag = 0;
			$class= 'enrolled';
			$enrolled_label='<span class="enrolled">'.__('enrolled','wplms-batches').'</span>';
		}	

		$count = groups_get_total_member_count($batch_id);
		$enable_seats = groups_get_groupmeta($batch_id,'enable_seats');
		if(!empty($enable_seats)){
			$batch_seats = groups_get_groupmeta($batch_id,'batch_seats');
		}
		$enable_batch_date = groups_get_groupmeta($batch_id,'enable_batch_date');
		if(!empty($enable_batch_date)){
			$access_within_dates = groups_get_groupmeta($batch_id,'access_within_dates');
			if(!empty($access_within_dates)){
				$end_batch_date = groups_get_groupmeta($batch_id,'end_batch_date');
				if(!empty($end_batch_date)){
					$end_time = strtotime($end_batch_date) + 86400;
					if($end_time < current_time('timestamp')){
						$enroll_flag = 0;
					}
				}
			}
		}

		echo '<li id="batch'.$batch_id.'" class="course_batch_grid '.(($grid == 'grid_2')?'col-md-6':'col-md-4').' '.apply_filters('wplms_course_batch_display_class',$class,$batch_id).'" >';
		?>
		<div class="batch_snapshot">
			<div class="batch_image">
				<a href="<?php echo $group_permalink; ?>"><?php echo $avatar; ?></a>
				<div class="labels"><?php echo $enrolled_label; if(!empty($enable_seats)){
									if($count >= $batch_seats){
										$enroll_flag = 0;
										echo '<span class="full">'.__('SEATS FULL','wplms-batches').'</span>';
									}
								}?>
				</div>
				<div class="batch_admins">
				<?php
					if(empty($batch->admins)){
						$admins = array($batch->creator_id);
					}else{
						$admins = $batch->admins;
					}
					foreach($admins as $admin_id){
					?>
						<a href="<?php echo bp_core_get_user_domain($admin_id); ?>" class="batch_admin">
						<?php echo bp_core_fetch_avatar( array(
				                'item_id' => $admin_id,
				                 'type' => 'thumb',
				                 'width'      => '64',
								 'height'     => '64',
				                 ));
				                 ?>
		                 </a>
	                 <?php
	             	}
                 	?>
             	</div>
         	</div>
			<div class="batch_content">
				<h4><a href="<?php echo $group_permalink; ?>"><?php echo $batch->name; ?></a></h4>
				<p><?php echo substr($batch->description,0,80); ?></p>
				<div class="batch_start_date"><label><?php _e('SEATS','wplms-batches'); ?></label>&nbsp;<span><?php 
				
				echo (empty($count)?1:$count); 
					if(!empty($enable_seats)){
						echo ' / '.$batch_seats;
					}
				?></span></div>
				<?php
				if(!empty($enable_seats)){
					?>
				<div class="progress" style="width:200px;height:4px;">
					<div class="bar" style="width:<?php echo round((100*$count/$batch_seats),0); ?>%;"></div>
				</div>
				<?php
				}

				$enable_batch_date = groups_get_groupmeta($batch_id,'enable_batch_date');
				if(!empty($enable_batch_date)){
					$start_batch_date = groups_get_groupmeta($batch_id,'start_batch_date');
					$end_batch_date = groups_get_groupmeta($batch_id,'end_batch_date');
					if(!empty($start_batch_date)){
						$start_time = strtotime($start_batch_date);
						echo '<div class="batch_start_date"><label>'.__('STARTS','wplms-batches').'</label><span>'.date_i18n( get_option( 'date_format' ), $start_time ).'</span></div>';
					}
					if(!empty($end_batch_date)){
						$end_time = strtotime($end_batch_date);
						$access_within_dates = groups_get_groupmeta($batch_id,'access_within_dates');
						if( !empty($access_within_dates) && (($end_time + 86400) < current_time('timestamp'))){
							$enroll_flag = 0;
						}
						echo '<div class="batch_end_date"><label>'.__('ENDS','wplms-batches').'</label><span>'.date_i18n( get_option( 'date_format' ), $end_time ).'</span></div>';
					}
				}
				$batch_timings = groups_get_groupmeta($batch_id,'batch_timings');
				if(!empty($batch_timings)){
					$batch_start_timing = groups_get_groupmeta($batch_id,'batch_start_time');
					$batch_end_timing = groups_get_groupmeta($batch_id,'batch_end_time');
					$batch_repeatable = groups_get_groupmeta($batch_id,'batch_repeatable');
					if(!empty($batch_start_timing[$course_id]) && !empty($batch_end_timing[$course_id])){
						echo '<div class="batch_timing"><label>'.__('TIMINGS','wplms-batches').'</label><span>'.$batch_start_timing[$course_id].' - '.$batch_end_timing[$course_id].'</span>';
						echo '</div>';

					if(!empty($batch_repeatable)){

					
						$batch_repeatable_parameter = groups_get_groupmeta($batch_id,'batch_repeatable_parameter');
						$batch_repeatable_parameter = $batch_repeatable_parameter[$course_id];
						$batch_repeatable = $batch_repeatable[$course_id];
						if(function_exists('calculate_duration_time')){
							$batch_repeatable_parameter = wplms_process_batch_duration($batch_repeatable_parameter);
							$batch_repeatable_parameter = calculate_duration_time($batch_repeatable_parameter);
							$batch_repeatable_parameter = translate($batch_repeatable_parameter,'vibe-customtypes');
						}
						echo '<div class="batch_timing"><label>'.__('Every','wplms-batches').'</label><span>'.$batch_repeatable.' '.$batch_repeatable_parameter.'</span></div>';
					}
					}
				}
				$enable_off_schedule =groups_get_groupmeta($batch_id,'enable_off_schedule');
				if(!empty($enable_off_schedule)){
					echo '<div class="weekly_off_schedule"><label>'.__('Weekly Schedule','wplms-batches').'</label>';
					$weekly_off_schedule =groups_get_groupmeta($batch_id,'weekly_off_schedule');
					if(!empty($weekly_off_schedule)){
						$days = array(
							1=>__('Monday','wplms-batches'),
							2=>__('Tuesday','wplms-batches'),
							3=>__('Wednesday','wplms-batches'),
							4=>__('Thursday','wplms-batches'),
							5=>__('Friday','wplms-batches'),
							6=>__('Saturday','wplms-batches'),
							7=>__('Sunday','wplms-batches'),
						);
						echo '<ul>';
						foreach($days as $k=>$day){
							echo '<li '.(in_array($k,$weekly_off_schedule)?'class="off"':'').'>'.substr($day,0,1).'</li>';
						}
						echo '</ul></div>';
					}
					$monthly_off_schedule =groups_get_groupmeta($batch_id,'monthly_off_schedule');
					$annual_off_schedule =groups_get_groupmeta($batch_id,'annual_off_schedule');
				}

				if($this->show_enroll_button && $enroll_flag){
					echo '<a data-batch="'.$batch_id.'" class="button enroll_in_batch">'.__('Enroll Now','wplms-batches').' &rsaquo;</a>';
					wp_nonce_field('enroll_now'.$batch_id.$user_id,'enroll_now'.$batch_id);
				}
				?>
			</div>
		</div>
		<?php
		echo '</li>';
	}

	function batch_list_style($batch_id){
		$enroll_flag= 1;
		$user_id = get_current_user_ID();
		$batch = groups_get_group( array( 'group_id' => $batch_id ) );
		
		$group_permalink = trailingslashit( bp_get_root_domain() . '/' . bp_get_groups_root_slug() . '/' . $batch->slug . '/' );
		$enrolled_label='';
		$member_batch = 0;
		if(wplms_batch_is_user_member( $user_id, $batch_id )){
			$member_batch = 1;
		}
		if(!empty($member_batch)){ 
			$enroll_flag = 0;
			$class= 'enrolled';
			$enrolled_label='<span class="enrolled">'.__('enrolled','wplms-batches').'</span>';
		}	

		$count = groups_get_total_member_count($batch_id);
		$enable_seats = groups_get_groupmeta($batch_id,'enable_seats');
		if(!empty($enable_seats)){
			$batch_seats = groups_get_groupmeta($batch_id,'batch_seats');
		}

		$enable_batch_date = groups_get_groupmeta($batch_id,'enable_batch_date');
		$access_within_dates = groups_get_groupmeta($batch_id,'access_within_dates');
		if(!empty($enable_batch_date) && !empty($access_within_dates)){
			$end_batch_date = groups_get_groupmeta($batch_id,'end_batch_date');
			if(!empty($end_batch_date)){
				$end_time = strtotime($end_batch_date)+86400;
				if($end_time < current_time('timestamp')){
					$enroll_flag = 0;
				}
			}
		}

		echo '<li id="batch'.$batch_id.'" class="course_batch_list '.apply_filters('wplms_course_batch_display_class',$class,$batch_id).'" >';
		?>
		<div class="batch_list"><h4><a href="<?php echo $group_permalink; ?>"><?php echo $batch->name; ?></a></h4><div class="labels"><?php echo $enrolled_label; if(!empty($enable_seats)){
									if($count >= $batch_seats){
										$enroll_flag = 0;
										echo '<span class="full">'.__('SEATS FULL','wplms-batches').'</span>';
									}
								}?>
				</div>
		<div class="batch_seats"><label><?php _e('SEATS','wplms-batches'); ?></label>&nbsp;<span><?php 
				
		echo (empty($count)?1:$count); 
			if(!empty($enable_seats)){
				echo ' / '.$batch_seats;
			}
		?></span></div>
		<?php
		if($enroll_flag && $this->show_enroll_button){
			echo '<a data-batch="'.$batch_id.'" class="button enroll_in_batch">'.__('Enroll Now','wplms-batches').' &rsaquo;</a>';
			wp_nonce_field('enroll_now'.$batch_id.$user_id,'enroll_now'.$batch_id);
		}
		?>
		<div class="batch_admins">
			<?php
				if(empty($batch->admins)){
					$admins = array($batch->creator_id);
				}else{
					$admins = $batch->admins;
				}
				foreach($admins as $admin_id){
				?>
					<a href="<?php echo bp_core_get_user_domain($admin_id); ?>" class="batch_admin">
					<?php echo bp_core_fetch_avatar( array(
			                'item_id' => $admin_id,
			                 'type' => 'thumb',
			                 'width'      => '64',
							 'height'     => '64',
			                 ));
			                 ?>
	                 </a>
                 <?php
             	}
         	?>
     	</div>
		<?php
		echo '</div></li>';
	}
}


Wplms_Batches_Init::init();