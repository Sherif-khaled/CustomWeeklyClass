<?php
/**
 * Batches Group Extension
 *
 * @class       BP_Group_Course_Batches
 * @author      VibeThemes
 * @category    Admin
 * @package     WPLMS-Batches/includes/batches
 * @version     1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! defined( 'WPLMS_BATCH_STATISITCS_SLUG' ) )
        define( 'WPLMS_BATCH_STATISITCS_SLUG', 'stats' );

if ( class_exists( 'BP_Group_Extension' ) ) :

    class BP_Group_Course_Batch_Statistics extends BP_Group_Extension {

    	var $message;

        function __construct() { 

            $args = array(
                'slug' => WPLMS_BATCH_STATISITCS_SLUG,
                'name' => __( 'Statistics', 'wplms-batches' ),
                'visibility'        => 'private',
                'nav_item_position' => 10,
                'enable_nav_item' => false,
                'screens' => array(
                    'admin' => array(
						'metabox_context'  => 'side',
						'metabox_priority' => 'core'
					),
					'create' => array(
						'enabled' => false,
					),
					'edit' => array(
						'enabled' => false,
					),
                )
            );
            $group_id = bp_get_group_id();
            global $bp;
            if(isset($bp->groups) && isset($bp->groups->current_group)){
                $enable = groups_get_groupmeta($bp->groups->current_group->id, 'course_batch' );
            }else{
                $enable = 0;
            }
            
            if(!empty($enable)){
                $args['enable_nav_item'] = true;
            }
            
            $flag = 1;
            $batch_stats_visibility = groups_get_groupmeta($bp->groups->current_group->id,'batch_stats_visibility');

           
            if(!empty($batch_stats_visibility)){
                $user_id = get_current_user_ID();
                if($batch_stats_visibility == 'mods'){
                    if(!groups_is_user_mod($user_id,$bp->groups->current_group->id)){
                        $flag = 0; 
                    }
                }else if($batch_stats_visibility == 'admins'){
                    if(!groups_is_user_admin($user_id,$bp->groups->current_group->id)){
                        $flag = 0;
                    }
                }
            }
            if($flag){
                parent::init( $args );
                add_action('wplms_batch_statistics',array($this,'batch_statistics'),10,1);
                add_action('wplms_batch_moderator_statistics',array($this,'moderator_statistics'),10,1);
                add_action('wp_ajax_get_batch_course_stats',array($this,'get_batch_course_stats'));
                add_action( 'bp_enqueue_scripts', array( $this, 'cssjs' ) );
            }
        }

        function cssjs(){
            if( bp_is_single_item() && bp_is_groups_component() && bp_is_current_action(WPLMS_BATCH_STATISITCS_SLUG) ){
                wp_enqueue_script('datatables-js',plugins_url( '../../assets/js/jquery.dataTables.min.js', __FILE__ ),array('jquery'));
                wp_enqueue_script('bootstrap-datatables-js',plugins_url( '../../assets/js/dataTables.bootstrap.min.js', __FILE__ ));
            }
        }
        /**
         * display() contains the markup that will be displayed on the main 
         * plugin tab
         */
        function display( $group_id = NULL ) {
            
            if(empty($group_id))
                $group_id = bp_get_group_id();


            do_action('wplms_batch_statistics',$group_id);
            if(bp_current_user_can( 'bp_moderate' )){
                do_action('wplms_batch_moderator_statistics',$group_id);
            }else{
                do_action('wplms_batch_student_statistics',$group_id);
            }

            $leaderboard = groups_get_groupmeta($group_id,'batch_leaderboard');
            if(bp_current_user_can( 'bp_moderate' ) || !empty($leaderboard)){
                echo '<h3 class="heading"><span>'._x('Leaderboard','Batch Leaderboard','wplms-batches').'</span></h3>';
                $members = BP_Groups_Member::get_group_member_ids($group_id);
                $courses = groups_get_groupmeta($group_id,'batch_course',false);
                if(empty($courses)){
                    echo '<div class="message">'.__('No Courses connected to Batch','wplms-batches').'</div>';
                    return;
                }
                $member_ids = implode(',',$members);
                $course_ids = implode(',',$courses);
                $course_status_string = '';
                foreach($courses as $c){
                    $course_status_string .= "'course_status".$c."',";
                }
                $course_status_string =trim($course_status_string, ",");
                global $wpdb,$bp;
                $results = $wpdb->get_results($wpdb->prepare("SELECT p.meta_key as uid,sum(p.meta_value) as sum 
                    FROM {$wpdb->postmeta} as p
                    LEFT JOIN {$wpdb->usermeta} as u
                    ON p.meta_key = u.user_id
                    WHERE p.meta_key IN ($member_ids) 
                    AND p.post_id IN ($course_ids) 
                    AND u.meta_key IN ($course_status_string)
                    AND u.meta_value > %d
                    GROUP BY uid ORDER BY sum DESC",3));
                ?>
                <table id="batch_leaderboard" class="table table-hover table-bordered">
                    <thead>
                        <tr>
                            <th rowspan="2"><?php _e('Rank','wplms-batches'); ?></th>
                            <th rowspan="2"><?php _e('Student','wplms-batches'); ?></th>
                            <th rowspan="1" colspan="<?php echo count($courses); ?>"><span style="width: 100%;text-align:center;display: inline-block;"><?php _e('Course','wplms-batches'); ?></span></th>
                            <th rowspan="2"><?php _e('Cumulative','wplms-batches'); ?></th>
                        </tr>
                        <tr>
                            <?php
                            foreach($courses as $course_id){
                                echo '<th><a href="'.get_permalink($course_id).'" target="_blank">'.get_the_title($course_id).'<a/></th>';
                            }
                            ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $i=1;
                        foreach($results as $member){
                            echo '<tr>
                            <td>'.$i.'</td>';
                            echo '<td><a href="'.bp_core_get_user_domain($member->uid).'" class="batch_member">
                                        '. bp_core_fetch_avatar( array(
                                                'item_id' => $member->uid,
                                                 'type' => 'thumb',
                                                 'width'      => '64',
                                                 'height'     => '64',
                                                 )).'<span>'.bp_core_get_user_displayname($member->uid).'</span></a></td>';
                            $sum=0;           
                            foreach($courses as $course_id){
                                $status = bp_course_get_user_course_status($member->uid,$course_id);
                                if($status > 3){
                                    $marks = get_post_meta($course_id,$member->uid,true);
                                    $sum += $marks;
                                    echo '<td>'.$marks.'</td>';    
                                }else{
                                    echo '<td>'._x('N.A','Marks not available in batch statisitcs leaderboard','wplms-batches').'</td>';
                                }
                                
                            }
                            echo '<td>'.$sum.'</td>';
                            echo '</tr>';
                            $i++;
                        }
                        ?>
                    </tbody>
                    <tfooter>
                    </tfooter>
                </table>
                <?php

            }
        }

        function batch_statistics($group_id){
            $courses = groups_get_groupmeta($group_id,'batch_course',false);
            if(empty($courses)){
                echo '<div class="message">'.__('No Courses connected to Batch','wplms-batches').'</div>';
                return;
            }
            $members = BP_Groups_Member::get_group_member_ids($group_id);
            $admins = groups_get_group_admins( $group_id );
            $mods = groups_get_group_mods( $group_id );

            global $wpdb,$bp;
            $batch_average = $batch_badge_count = $batch_certificate_count = 0;
            $batch_average = groups_get_groupmeta($group_id,'batch_average');
            $batch_badge_count = groups_get_groupmeta($group_id,'batch_badge_count');
            $batch_certificate_count = groups_get_groupmeta($group_id,'batch_certificate_count');
            if(isset($_GET['recalculate'])){
                $total_marks = 0;$total_denom = 1;
                foreach($members as $member_id){
                    foreach($courses as $course_id){
                        $status = bp_course_get_user_course_status($member_id,$course_id);
                        if($status > 3){
                            $marks = get_post_meta($course_id,$member_id,true);
                            $total_marks += $marks;
                            $total_denom++;
                        }
                    }
                    $certificates = get_user_meta($member_id,'certificates',true);
                    $badges = get_user_meta($member_id,'badges',true);
                    if(!empty($certificates)){
                        foreach($certificates as $certificate_course_id){
                            if(in_array($certificate_course_id,$courses)){
                                $batch_certificate_count++;
                            }
                        }    
                    }
                    if(!empty($badges)){
                        foreach($badges as $badges_course_id){
                            if(in_array($badges_course_id,$courses)){
                                $batch_badge_count++;
                            }
                        }    
                    }
                }
                if($total_denom > 1){
                    $total_denom--;
                }
                $batch_average = round($total_marks/$total_denom,2);
                groups_update_groupmeta($group_id,'batch_average',$batch_average);
                groups_update_groupmeta($group_id,'batch_badge_count',$batch_badge_count);
                groups_update_groupmeta($group_id,'batch_certificate_count',$batch_certificate_count);
            }

            
            ?>
            <h3 class="heading"><span><?php _e('Batch Statistics','wplms-batches'); ?></span></h3>
            <div class="row">
                <div class="col-md-6">
                    <ul class="simple_batch_statistics">
                        <li><strong><?php _e('Total members in Batch'); ?></strong><span><?php echo count($members); ?></span></li>
                        <li><strong><?php _e('Total Students in Batch'); ?></strong><span><?php echo (count($members)-count($admins)-count($mods)); ?></span></li>
                        <li><strong><?php _e('Average Course percentage in Batch'); ?></strong><span><?php echo (empty($batch_average)?0:$batch_average); ?></span></li>
                        <li><strong><?php _e('Students who got excellence Badge'); ?></strong><span><?php echo (empty($batch_badge_count)?0:$batch_badge_count); ?></span></li>
                        <li><strong><?php _e('Students who earned certificate'); ?></strong><span><?php echo (empty($batch_certificate_count)?0:$batch_certificate_count); ?></span></li>
                    </ul>
                </div>
                <div class="col-md-6">
                    <div class="batch_average">
                            <h5><?php _e('Average Marks in Batch ','vibe'); ?></h5>
                            <input type="text" class="big_dial" data-max="100" value="<?php echo (empty($batch_average)?0:$batch_average); ?>">
                            <a href="?recalculate" class="link clear"><?php echo _x('Recalculate','Recalculate batch statistics','wplms-batches')?></a>
                        </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="course_stats_form">
                        <h3 class="heading"><span><?php _e('Course Specific Statistics','wplms-batches'); ?></span></h3>
                        <select id="batch_course" >
                            <?php
                                foreach($courses as $course){
                                    echo '<option value="'.$course.'">'.get_the_title($course).'</option>';
                                }
                            ?>
                        </select>
                        <?php wp_nonce_field('batch_course_security'.$group_id,'batch_course_security'); 
                        echo '<input type="hidden" id="course_batch_id" value="'.$group_id.'" />'; ?>
                        <a id="get_batch_course_stats" class="button"><?php _e('Get Stats','wplms-batches'); ?></a>
                    </div>
                </div>
            </div>
            <?php
        }
        function moderator_statistics($group_id){

            $courses = groups_get_groupmeta($group_id,'batch_course',false);
            if(empty($courses)){
                echo '<div class="message">'.__('No Courses connected to Batch','wplms-batches').'</div>';
                return;
            }

            ?>

            <?php
            $members = BP_Groups_Member::get_group_member_ids($group_id);

        }

        function get_batch_course_stats(){
            $course_id = $_POST['course_id'];
            $batch_id = $_POST['batch_id'];
            $user_id = get_current_user_ID();
            if ( !isset($_POST['security']) || !wp_verify_nonce($_POST['security'],'batch_course_security'.$batch_id) || !is_numeric($course_id) || !is_numeric($batch_id)){
                _e('Security check Failed. Contact Administrator.','wplms-batches');
                die();
            }

            echo '<h5>'.sprintf(__('Statistics for Course %s','wplms-batches'),'<a href="'.get_permalink($course_id).'" target="_blank">'.get_the_title($course_id)).'</a></h5>';
            if(function_exists('bp_course_get_curriculum_quizes')){
                $quiz_ids = bp_course_get_curriculum_quizes($course_id);    
            }
            if(function_exists('wplms_course_get_course_assignments')){
                $assignment_ids = wplms_course_get_course_assignments($course_id);    
            }
            $flag = 0;
            if(!empty($quiz_ids)){
                $flag++;
            }
            if(!empty($assignment_ids)){
                $flag++;
            }
            ?>
            <table class="course_leaderboard table table-hover table-bordered">
                <thead>
                    <tr>
                        <th rowspan="<?php echo (!empty($flag)?2:1); ?>">#</th>
                        <th rowspan="<?php echo (!empty($flag)?2:1); ?>"><?php _e('Student','wplms-batches'); ?></th>
                        <th rowspan="<?php echo (!empty($flag)?2:1); ?>"><?php _e('Progress','wplms-batches'); ?></th>
                        <?php
                            if($flag >= 1){
                                echo '<th rowspan="1" colspan="'.count($quiz_ids).'"><span style="width: 100%;text-align:center;display: inline-block;">'.__('Quizzes','wplms-batches').'</span></th>';
                            }
                            if($flag >= 2){
                                echo '<th rowspan="1" colspan="'.count($assignment_ids).'"><span style="width: 100%;text-align:center;display: inline-block;">'.__('Assignments','wplms-batches').'</span></th>';
                            }
                        ?>
                        <th rowspan="<?php echo (!empty($flag)?2:1); ?>"><?php _e('Cumulative','wplms-batches'); ?></th>
                    </tr>
                    <tr>
                        <?php
                        if($flag >= 1){
                            foreach($quiz_ids as $quiz_id){
                                echo '<th><a href="'.get_permalink($quiz_id).'" target="_blank">'.get_the_title($quiz_id).'</a></th>';
                            }
                        }
                        if($flag >= 2){
                            foreach($assignment_ids as $assignment_id){
                                echo '<th><a href="'.get_permalink($assignment_id).'" target="_blank">'.get_the_title($assignment_id).'</a></th>';
                            }
                        }
                        ?>
                    </tr>
                </thead>
                <tbody>
                <?php
                $members = BP_Groups_Member::get_group_member_ids($batch_id);
                $i=1;
                foreach($members as $member_id){
                    echo '<tr>
                    <td>'.$i.'</td>';
                    echo '<td><a href="'.bp_core_get_user_domain($member_id).'" class="batch_member">
                                '. bp_core_fetch_avatar( array(
                                        'item_id' => $member_id,
                                         'type' => 'thumb',
                                         'width'      => '64',
                                         'height'     => '64',
                                         )).'<span>'.bp_core_get_user_displayname($member_id).'</span></a></td>';
                    $progress = bp_course_get_user_progress($member_id,$course_id);
                    echo '<td>'.(empty($progress)?0:$progress).'</td>';
                    if($flag >= 1){
                        foreach($quiz_ids as $quiz_id){
                            echo '<td>'.get_post_meta($quiz_id,$member_id,true).'</td>';
                        }
                    }
                    if($flag >= 2){
                        foreach($assignment_ids as $assignment_id){
                            echo '<td>'.get_post_meta($assignment_id,$member_id,true).'</td>';
                        }
                    }            
                    $sum=0;           
                    $status = bp_course_get_user_course_status($member_id,$course_id);
                    if($status > 3){
                        $marks = get_post_meta($course_id,$member_id,true);
                        $sum += $marks;
                        echo '<td>'.$marks.'</td>';    
                    }else{
                        echo '<td>'._x('N.A','Marks not available in batch statisitcs leaderboard','wplms-batches').'</td>';
                    }
                    echo '</tr>';
                    $i++;
                }
                ?>
                </tbody>
            </table>
            <?php
            die();
        }
    }

add_action( 'bp_init','wplms_batch_statistics_register_group_extension'); 
function wplms_batch_statistics_register_group_extension(){ 
    bp_register_group_extension( 'BP_Group_Course_Batch_Statistics' );
}
endif;