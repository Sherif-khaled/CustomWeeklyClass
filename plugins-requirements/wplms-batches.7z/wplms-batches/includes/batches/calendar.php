<?php
/**
 * Batches Group Extension
 *
 * @class       BP_Group_Course_Batches
 * @author      VibeThemes
 * @category    Admin
 * @package     WPLMS-Batches/includes/batches
 * @version     1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
 