<?php
/**
 * Batches Group Extension
 *
 * @class       BP_Group_Course_Batches
 * @author      VibeThemes
 * @category    Admin
 * @package     WPLMS-Batches/includes/batches
 * @version     1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! defined( 'WPLMS_BATCH_SLUG' ) )
		define( 'WPLMS_BATCH_SLUG', 'batch' );

if ( class_exists( 'BP_Group_Extension' ) ) :

    class BP_Group_Course_Batches extends BP_Group_Extension {

    	var $message;

        function __construct() { 

            $args = array(
                'slug' => WPLMS_BATCH_SLUG,
                'name' => __( 'Batch', 'wplms-batches' ),
                'visibility'        => 'noone',
                'nav_item_position' => 10,
                'enable_nav_item' => false,
                'screens' => array(
                    'admin' => array(
						'metabox_context'  => 'side',
						'metabox_priority' => 'core'
					),
					'create' => array(
						'enabled' => false,
					),
					'edit' => array(
						'enabled' => true,
					),
                )
            );
            $b = WPLMS_Batch_Template::init();
            
            $this->batch = $b->get();
            if(!empty($this->batch->enable)){
            	$args['enable_nav_item'] = true;
            }
            parent::init( $args );

            add_action('wplms_batches_courses',array($this,'batch_courses'));

            add_action('wplms_batches_events',array($this,'batch_events'));
            add_action('wplms_batches_schedule',array($this,'batch_schedule'));
            add_action('wplms_batches_email',array($this,'batch_email'));

            add_action( 'bp_enqueue_scripts', array( $this, 'cssjs' ) );
            add_action( 'admin_enqueue_scripts', array( $this, 'admin_cssjs' ) );
            add_action('wp_ajax_fetch_schedule',array($this,'wplms_batch_schedule'));
            add_filter('eventon_wp_query_args',array($this,'wplms_events'),10,3);
            add_action('eventon_calendar_header_content',array($this,'wplms_hidden_batch_element'),10,2);
            add_filter('eventon_wp_query_args',array($this,'wplms_ajax_events'),10,2);
        }

        function cssjs(){
        	if( bp_is_single_item() && bp_is_groups_component() && bp_is_current_action(WPLMS_BATCH_SLUG) ){
        		wp_enqueue_script('moment',plugins_url('../../assets/js/moment.min.js',__FILE__),array('jquery'));
        		wp_enqueue_script('fullcalendar',plugins_url('../../assets/js/fullcalendar.min.js',__FILE__),array('jquery'));
        		wp_enqueue_style('fullcalendar',plugins_url('../../assets/css/fullcalendar.css',__FILE__));
        	}
        }

        function admin_cssjs(){
        	
			if(defined('VIBE_PLUGIN_URL')){
				if($_REQUEST['page']=='bp-groups'){
					wp_deregister_script('select2');
		        	wp_enqueue_script( 'select2', VIBE_PLUGIN_URL .'/vibe-customtypes/metaboxes/js/select2.min.js');
				}
			}
        }
        /**
	     * display() contains the markup that will be displayed on the main 
	     * plugin tab
	     */
	    function display( $group_id = NULL ) {
	        
	        ?>
	        <div class="batch_details">
			  <!-- Nav tabs -->
			  <ul class="nav nav-tabs" role="tablist">
			  	<?php
			  	$batch_tabs = array(
			  		'courses' => __('Courses','wplms-batches'),
			  		'details' => __('Details','wplms-batches'),
			  		);

			  	//IF EVENTS
			  	
			  	if(!empty($batch->batch_events)){
			  		$batch_tabs['events'] = __('Events','wplms-batches');
			  	}
			  	//IF SCHEDULE
			  	if(!empty($batch->batch_timings)){
			  		$batch_tabs['schedule'] = __('Schedule','wplms-batches');
			  	}
			  	// EMAIL
			  	if(current_user_can( 'bp_moderate' )){
			  		$batch_tabs['email'] = __('Email','wplms-batches');
			  	}

			  	$batch_tabs = apply_filters('wplms_batch_detail_tabs',$batch_tabs,$group_id);
			  	$i=0;
			  	foreach($batch_tabs as $id => $label){

			  	?>
			    <li <?php echo (empty($i)?'class="active"':''); ?>><a href="#<?php echo $id; ?>" data-toggle="tab"><?php echo $label; ?></a></li>
			    <?php
			    	$i++;
				}
			    ?>
			  </ul>

			  <!-- Tab panes -->
			  <div class="tab-content">
			  	<?php
			  	$i=0;
			  		foreach($batch_tabs as $id => $label){
			  	?>
			    <div class="tab-pane  <?php echo (empty($i)?'active':''); ?>" id="<?php echo $id; ?>">
			    	<?php do_action('wplms_batches_'.$id); ?>
			    </div>
			    <?php
			    	$i++;
		    		}
			    ?>
			  </div>
			  <?php wp_nonce_field('wplms_batches','batch_security'); ?>
			</div>
			<?php
	        
	    }
        /**
         * settings_screen() is the catch-all method for displaying the content
         * of the edit, create, and Dashboard admin panels
         * @param integer|null $group_id
         */
        function settings_screen( $group_id = NULL ) {

        	$batch = $this->batch;
			wp_enqueue_script('jquery-ui-datepicker');
			wp_enqueue_script( 'timepicker_box', VIBE_PLUGIN_URL . '/vibe-customtypes/metaboxes/js/jquery.timePicker.min.js', array( 'jquery' ) );
			if(!empty($this->message)){
				echo $this->message;
			}
           ?>
            <p><?php _e('If this group is used as a Course Batch enable and configure below settings.', 'wplms-batches' ); ?></p>
            <?php wp_nonce_field( $group_id ); ?>
            <p><div class="checkbox"><input type="checkbox" name="course_batch" id="course_batch" value="1" <?php checked($batch->enable,1); ?> style="float:left;margin-right:10px;" /><label for="course_batch"><?php _e('Enable Course Batches for this Group', 'wplms-batches' ); ?></label></div></p>
			<script>
				jQuery(document).ready(function($){
					$('#course_batch').click(function(){$('.enabled_course_batch').toggle(200);});
					$('#batch_timings').click(function(){$('.course_timings').toggle(200);});
					$('.timepicker').timePicker({
	                      show24Hours: true,
	                      separator:":",
	                      step: 15
	                  });
				});
			</script><style>
			div.time-picker{position:absolute;height:191px;width:4em;overflow:auto;background:#fff;border:1px solid #aaa;z-index:99;margin:0}div.time-picker-12hours{width:6em}div.time-picker ul{list-style-type:none;margin:0;padding:0}div.time-picker li{cursor:pointer;font:12px/1 Helvetica,Arial,sans-serif;padding:4px 3px}div.time-picker li.selected{background:#0063CE;color:#fff}
			</style>
			<br />
			<div class="enabled_course_batch" <?php if(!empty($batch->enable)){echo 'style="display:block;"';}else{echo 'style="display:none;"';} ?>>
				<p><label><?php _e('Select Courses.', 'wplms-batches' ); ?></label>
				<select name="batch_course[]" class="form_field chosen" multiple>
					<option value=""><?php _e('None','wplms-batches'); ?></option>
                    <?php
                        $args= array(
                        'post_type'=> 'course',
                        'posts_per_page'=> -1
                        );
                        $args = apply_filters('wplms_frontend_cpt_query',$args);
                        
                        $kposts=get_posts($args);

                        foreach ( $kposts as $kpost ){
                            echo '<option value="' . $kpost->ID . '" '.(((is_array($batch->courses) && in_array($kpost->ID,$batch->courses)) || ($kpost->ID == $batch->courses) )?'selected':'').'>' . $kpost->post_title . '</option>';
                        }
                    ?>
				</select>
				</p>
				<?php
				$visibility_flag = apply_filters('wplms_batches_enable_batch_course_visibility_switch',0);
				if($visibility_flag){
				?>
				<p><div class="checkbox"><input type="checkbox" name="batch_course_visibility" id="batch_course_visibility" value="1" <?php checked($batch->batch_course_visibility,1); ?> style="float:left;margin-right:10px;" /><label for="batch_course_visibility"><?php _e('Students in Batch can only view courses connected to this batch', 'wplms-batches' ); ?></label></div></p>	
				<?php
				}
				?>	
				<div class="checkbox">
					<input type="checkbox" name="enable_batch_duration" id="enable_batch_duration" value="1" <?php checked($batch->enable_batch_duration,1); ?> style="float:left;margin-right:10px;" />
					<label for="enable_batch_duration"><?php _e('Enable Batch Duration', 'wplms-batches' ); ?><span><?php _e('Overrides course duration for batch students', 'wplms-batches' ); ?></span></label>
				</div>
				<p><label><?php _e('Batch Duration ','wplms-batches'); ?></label>
						<input type="number" name="batch_duration" value="<?php echo $batch->batch_duration; ?>"/>
						<select name="batch_duration_parameter">
							<option value="minute" <?php selected('minute',$batch->batch_duration_parameter); ?>><?php _e('Minutes','wplms-batches'); ?></option>
							<option value="hour" <?php selected('hour',$batch->batch_duration_parameter); ?>><?php _e('Hour','wplms-batches'); ?></option>
							<option value="day" <?php selected('day',$batch->batch_duration_parameter); ?>><?php _e('Day','wplms-batches'); ?></option>
							<option value="week" <?php selected('week',$batch->batch_duration_parameter); ?>><?php _e('Week','wplms-batches'); ?></option>
							<option value="fortnight" <?php selected('fortnight',$batch->batch_duration_parameter); ?>><?php _e('Fortnight','wplms-batches'); ?></option>
							<option value="month" <?php selected('month',$batch->batch_duration_parameter); ?>><?php _e('Month','wplms-batches'); ?></option>
							<option value="year" <?php selected('year',$batch->batch_duration_parameter); ?>><?php _e('Year','wplms-batches'); ?></option>
						</select>
				</p>
				<div class="checkbox">
					<input type="checkbox" name="enable_seats" id="enable_seats" value="1" <?php checked($batch->enable_seats,1); ?> style="float:left;margin-right:10px;" />
					<label for="enable_seats"><?php _e('Enable Batch Seats', 'wplms-batches' ); ?><span><?php _e('Override course seats for batch students', 'wplms-batches' ); ?></span></label>
				</div>
				<p><label><?php _e('Number of Seats'); ?></label><input type="number" name="batch_seats" value="<?php echo $batch->batch_seats; ?>" />
				</p>
				<p><div class="checkbox"><input type="checkbox" name="batch_leaderboard" id="batch_leaderboard" value="1" <?php checked($batch->batch_leaderboard,1); ?> style="float:left;margin-right:10px;" /><label for="batch_leaderboard"><?php _e('Enable Batch Leaderboard visibility to students', 'wplms-batches' ); ?></label></div></p>	
				<div class="checkbox">
					<input type="checkbox" name="enable_batch_date" id="enable_batch_date" value="1" <?php checked($batch->enable_batch_date,1); ?> style="float:left;margin-right:10px;" />
					<label for="enable_batch_date"><?php _e('Enable Batch Start/End Date', 'wplms-batches' ); ?></label>
				</div>
				<div id="batch_dates">
					<p><label><?php _e('Start Date'); ?></label><input type="text" name="start_batch_date" id="start_batch_date" class="datepicker" value="<?php echo $batch->start_batch_date; ?>" /></p>
					<p><label><?php _e('End Date'); ?></label><input type="text" name="end_batch_date" id="end_batch_date" class="datepicker" value="<?php echo $batch->end_batch_date; ?>" /></p>
				</div>	
				<p><div class="checkbox"><input type="checkbox" name="access_within_dates" id="access_within_dates" value="1" <?php checked($batch->access_within_dates,1); ?> style="float:left;margin-right:10px;" /><label for="access_within_dates"><?php _e('Enable Course access within Start/End Dates', 'wplms-batches' ); ?></label></div></p>
					<div class="checkbox">
						<input type="checkbox" name="enable_off_schedule" id="enable_off_schedule" value="1" <?php checked($batch->enable_off_schedule,1); ?> style="float:left;margin-right:10px;" />
						<label for="enable_off_schedule"><?php _e('Enable Off Schedule', 'wplms-batches' ); ?></label>
					</div>
					<div id="off_schedule">
						<div class="weekly_off_schedule">
							<label><?php _e('Set Weekly off days','wplms-batches'); ?></label>
							<select class="select2" name="weekly_off_schedule[]" data-placeholder="<?php _e('Set weekly off days','wplms-batches'); ?>" multiple>
								<?php
								$days = array(
									1=>__('Monday','wplms-batches'),
									2=>__('Tuesday','wplms-batches'),
									3=>__('Wednesday','wplms-batches'),
									4=>__('Thursday','wplms-batches'),
									5=>__('Friday','wplms-batches'),
									6=>__('Saturday','wplms-batches'),
									7=>__('Sunday','wplms-batches'),
								);

								for($i=1;$i<=7;$i++){
									echo '<option value="'.$i.'" '.((is_array($batch->weekly_off_schedule) && in_array($i,$batch->weekly_off_schedule))?'selected':'').'>'.$days[$i].'</option>';
								}
								?>
							</select>
						</div>
						<div class="monthly_off_schedule">
							<label><?php _e('Set Monthly off days','wplms-batches'); ?></label>
							<select class="select2" name="monthly_off_schedule[]" data-placeholder="<?php _e('Set monthly off days','wplms-batches'); ?>" multiple>
								<?php
								for($i=1;$i<=31;$i++){
									echo '<option value="'.$i.'" '.((is_array($batch->monthly_off_schedule) && in_array($i,$batch->monthly_off_schedule))?'selected':'').'>'.$i.'</option>';
								}
								?>
							</select>
						</div>
						<div class="annual_off_schedule">
							<label><?php _e('Set specific dates','wplms-batches'); ?></label>
							<select class="select2" name="annual_off_schedule[]" data-placeholder="<?php _e('Set specific dates','wplms-batches'); ?>" multiple>
								<?php
								$months = array(
									1=>__('January','wplms-batches'),
									2=>__('February','wplms-batches'),
									3=>__('March','wplms-batches'),
									4=>__('April','wplms-batches'),
									5=>__('May','wplms-batches'),
									6=>__('June','wplms-batches'),
									7=>__('July','wplms-batches'),
									8=>__('August','wplms-batches'),
									9=>__('Sepetember','wplms-batches'),
									10=>__('October','wplms-batches'),
									11=>__('November','wplms-batches'),
									12=>__('December','wplms-batches'),
								);
								for($i=1;$i<=12;$i++){
									for($j=1;$j<=31;$j++){
										echo '<option value="'.$i.'-'.$j.'" '.((is_array($batch->annual_off_schedule) && in_array($i.'-'.$j,$batch->annual_off_schedule))?'selected':'').'>'.$j.' '.$months[$i].'</option>';
									}
								}
								?>
							</select>
						</div>
					</div>
				<p><div class="checkbox"><input type="checkbox" name="batch_timings" id="batch_timings" value="1" <?php checked($batch->timings,1); ?> style="float:left;margin-right:10px;" /><label for="batch_timings"><?php _e('Enable Batch Timings', 'wplms-batches' ); ?></label></div></p>					
				<div class="course_timings" <?php echo (empty($batch->timings)?'style="display:none;"':'');?>>
				<?php
				if(empty($batch->courses)){
					echo '<div class="message">'.__('Batch timings can only be set for saved courses. Please set & save courses in batch and then check this section.','wplms-batches').'</div>';
				}else{
					foreach($batch->courses as $course_id){
				?>
				<br /><h5><?php echo sprintf(__('Batch Timings for course %s','wplms-batches'),'<strong>'.get_the_title($course_id).'</strong>'); ?></h5>
					<p><label><?php _e('Start Time','wplms-batches'); ?></label><input type="text" name="batch_start_time[<?php echo $course_id; ?>]" class="timepicker" id="start_time<?php echo $course_id; ?>" value="<?php echo $batch->batch_start_time[$course_id]; ?>" /></p>
					<p><label><?php _e('End Time','wplms-batches'); ?></label><input type="text" name="batch_end_time[<?php echo $course_id; ?>]" class="timepicker" id="end_time<?php echo $course_id; ?>" value="<?php echo $batch->batch_end_time[$course_id]; ?>" /></p>
					<p><label><?php _e('Every ','wplms-batches'); ?></label>
						<input type="number" name="batch_repeatable[<?php echo $course_id; ?>]" value="<?php echo $batch->batch_repeatable[$course_id]; ?>"/>
						<select name="batch_repeatable_parameter[<?php echo $course_id; ?>]">
							<option value="day" <?php selected('day',$batch->batch_repeatable_parameter[$course_id]); ?>><?php _e('Day','wplms-batches'); ?></option>
							<option value="week" <?php selected('week',$batch->batch_repeatable_parameter[$course_id]); ?>><?php _e('Week','wplms-batches'); ?></option>
							<option value="month" <?php selected('month',$batch->batch_repeatable_parameter[$course_id]); ?>><?php _e('Month','wplms-batches'); ?></option>
							<option value="year" <?php selected('year',$batch->batch_repeatable_parameter[$course_id]); ?>><?php _e('Year','wplms-batches'); ?></option>
						</select>
					</p>
					<p><div class="checkbox"><input type="checkbox" name="batch_timing_course_accessibility[<?php echo $course_id; ?>]" id="batch_timing_course_accessibility<?php echo $course_id; ?>" value="1" <?php checked($batch->batch_timing_course_accessibility[$course_id],1); ?> style="float:left;margin-right:10px;" /><label for="batch_timing_course_accessibility<?php echo $course_id; ?>"><?php _e('Enable Course accessibility within Batch timings', 'wplms-batches' ); ?></label></div></p>	
				<?php
						}
					}
				?>	
				</div>
				<p><div class="checkbox"><input type="checkbox" name="batch_events" id="batch_events" value="1" <?php checked($batch->batch_events,1); ?> style="float:left;margin-right:10px;" /><label for="batch_events"><?php _e('Enable Events for this batch', 'wplms-batches' ); ?></label></div></p>
				<p><label><?php _e('Batch Statistics Visibility','wplms-batches'); ?></label>
				<select name="batch_stats_visibility">
					<option value='' <?php selected($batch->batch_stats_visibility,'');?>><?php _ex('All Members','Batch settings','wplms-batches'); ?></option>
					<option value='mods' <?php selected($batch->batch_stats_visibility,'mods');?>><?php _ex('Mods & Admins','Batch settings','wplms-batches'); ?></option>
					<option value='admins' <?php selected($batch->batch_stats_visibility,'admins');?>><?php _ex('Admins only','Batch settings','wplms-batches'); ?></option>
				</select>
				</p>
				<p><div class="checkbox"><input type="checkbox" name="batch_exclusivity" id="batch_exclusivity" value="1" <?php checked($batch->batch_exclusivity,1); ?> style="float:left;margin-right:10px;" /><label for="batch_exclusivity"><?php _e('Hide "Join/Request" buttons, useful for Batch exclusivity.', 'wplms-batches' ); ?></label></div></p>
				<?php do_action('bp_group_course_batch_settings',$group_id); ?>
			</div><br />
            <input type="submit" name="bp_groups_save_course_batch" id="bp_groups_save_course_batch" value="<?php esc_attr_e( 'Save Batch Settings', 'wplms-batches' ); ?>" />
            <input type="hidden" name="group_id" value="<?php echo $group_id;?>" />
            <script>
            	jQuery(document).ready(function($){
					if(!$('#enable_seats').is(':checked')){ 
						$('#enable_seats').parent().next().hide();
					}
					if(!$('#enable_batch_date').is(':checked')){
						$('#batch_dates').hide();
					}
					if(!$('#enable_batch_duration').is(':checked')){
						$('#enable_batch_duration').parent().next().hide();
					}
					if(!$('#enable_off_schedule').is(':checked')){
						$('#off_schedule').hide();	
					}
					$('#enable_seats').parent().on('click',function(){
						if($('#enable_seats').is(':checked')){
							$('#enable_seats').parent().next().show(100);
						}else{
							$('#enable_seats').parent().next().hide(100);
						}
					});

					$('#enable_batch_duration').parent().on('click',function(){
						if($('#enable_batch_duration').is(':checked')){
							$('#enable_batch_duration').parent().next().show(100);
						}else{
							$('#enable_batch_duration').parent().next().hide(100);
						}
					});
					$('#enable_batch_date').parent().on('click',function(){
						if($('#enable_batch_date').is(':checked')){
							$('#batch_dates').show(100);
						}else{
							$('#batch_dates').hide(100);
						}
					});
					$('#enable_off_schedule').parent().on('click',function(){
						if($('#enable_off_schedule').is(':checked')){
							$('#off_schedule').show(100);	
						}else{
							$('#off_schedule').hide(100);	
						}
					});
					$('.select2').select2();
				});
			</script>
			<style>
			.select2-container{min-width:220px;}
			.checkbox label>span{margin:0 15px;font-size: 11px;text-transform: uppercase;color: #bbb;}
			</style>
        <?php
        }

        /**
         * settings_screen_save() contains the catch-all logic for saving
         * settings from the edit, create, and Dashboard admin panels
         * @param $group_id int
         */
        function settings_screen_save( $group_id = NULL ) {

        	
        	if(empty($_POST['bp_groups_save_course_batch'])) 
        		return;
			
			$group_id = $_POST['group_id'];

			if ( !isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'],$group_id) ){ 

				    $this->message = '<div class="error message">'.__('Security check Failed. Contact Administrator.','wplms-batches' ).'</div>';
			}else{
					if(isset($_POST['course_batch'])){
						
						groups_update_groupmeta( $group_id, 'course_batch',$_POST['course_batch'] );

						if(!empty($_POST['batch_course'])){
							if(is_array($_POST['batch_course'])){
								
								groups_delete_groupmeta($group_id,'batch_course',false);

								$course_ids = array_unique($_POST['batch_course']);
								$cids = groups_get_groupmeta($group_id,'batch_course',false);

								foreach($course_ids as $course_id){
									if(is_array($cids) && !in_Array($course_id,$cids)){
										groups_add_groupmeta($group_id,'batch_course',$course_id);	
									}else{
										groups_add_groupmeta($group_id,'batch_course',$course_id);
									}
								}
							}else{
								groups_update_groupmeta($group_id,'batch_course',$_POST['batch_course']);
							}
						}

						groups_update_groupmeta($group_id,'batch_course_visibility',$_POST['batch_course_visibility']);

						groups_update_groupmeta($group_id,'enable_batch_duration',$_POST['enable_batch_duration']);
						groups_update_groupmeta($group_id,'batch_duration',$_POST['batch_duration']);
						groups_update_groupmeta($group_id,'batch_duration_parameter',$_POST['batch_duration_parameter']);
						groups_update_groupmeta($group_id,'batch_events',$_POST['batch_events']);
						groups_update_groupmeta($group_id,'batch_exclusivity',$_POST['batch_exclusivity']);
						
						groups_update_groupmeta($group_id,'batch_leaderboard',$_POST['batch_leaderboard']);
						
						groups_update_groupmeta($group_id,'enable_off_schedule',$_POST['enable_off_schedule']);
						groups_update_groupmeta($group_id,'weekly_off_schedule',$_POST['weekly_off_schedule']);
						groups_update_groupmeta($group_id,'monthly_off_schedule',$_POST['monthly_off_schedule']);
						groups_update_groupmeta($group_id,'annual_off_schedule',$_POST['annual_off_schedule']);


						groups_update_groupmeta($group_id,'enable_seats',$_POST['enable_seats']);
						groups_update_groupmeta($group_id,'batch_seats',$_POST['batch_seats']);	
					
					
						groups_update_groupmeta($group_id,'enable_batch_date',$_POST['enable_batch_date']);
						groups_update_groupmeta($group_id,'start_batch_date',$_POST['start_batch_date']);
						groups_update_groupmeta($group_id,'end_batch_date',$_POST['end_batch_date']);
						
						
						groups_update_groupmeta($group_id,'batch_start_time',$_POST['batch_start_time']);
						groups_update_groupmeta($group_id,'access_within_dates',$_POST['access_within_dates']);
						groups_update_groupmeta($group_id,'batch_end_time',$_POST['batch_end_time']);
						groups_update_groupmeta($group_id,'batch_timing_course_accessibility',$_POST['batch_timing_course_accessibility']);

						groups_update_groupmeta($group_id,'display_schedule',$_POST['display_schedule']);
						groups_update_groupmeta($group_id,'batch_timings',$_POST['batch_timings']);
						groups_update_groupmeta($group_id,'batch_repeatable',$_POST['batch_repeatable']);
						groups_update_groupmeta($group_id,'batch_repeatable_parameter',$_POST['batch_repeatable_parameter']);
						
						groups_update_groupmeta($group_id,'batch_stats_visibility',$_POST['batch_stats_visibility']);

						$this->message = '<div class="success message">'.__('Batch Details saved','wplms-batches' ).'</div>';
					}else{
						groups_update_groupmeta( $group_id, 'course_batch');
						groups_delete_groupmeta($group_id,'batch_course');
					}
				}

        }

        function batch_courses(){
        	$group_id = bp_get_group_id();
	        $course_ids = $this->batch->courses;
	        $course_ids = array_unique($course_ids);
	        echo '<div class="batch_courses">';
	        foreach($course_ids as $course_id){
	        	echo '<div class="row">';
	        	echo '<div class="col-md-3 col-sm-3">'.get_the_post_thumbnail($course_id,'full').'</div>';
	        	echo '<div class="col-md-6 col-sm-6">
	        	<h5><a href="'.get_permalink($course_id).'">'.get_the_title($course_id).'</a></h5>';
	        	echo '<div class="course_excerpt">'.get_post_field('post_excerpt',$course_id).'</div>';
	        	echo '</div><div class="col-md-3 col-sm-3">';
	        	$rating = get_post_meta($course_id,'average_rating',true);
	        	if(empty($rating)){$rating=0;}
	        	echo '<div class="course_rating"><span class="mega_text">'.(empty($rating)?__('N.A','wplms-batches'):$rating).'</span>';
	        	echo bp_course_display_rating($rating);
	        	if(is_user_logged_in()){
	        		$user_id = get_current_user_id();
	        		if(bp_course_is_member($course_id,$user_id)){
	        			$progress = bp_course_get_user_progress($user_id,$course_id); 
	        			echo do_shortcode('[progressbar percentage="'.(empty($progress)?0:$progress).'"]');
	        		}
	        	}
	        	echo '</div>';

	        	echo '</div></div><hr />';
	        }
	        echo '</div>';
        }

        function batch_events(){
        	$group_id = bp_get_group_id();

	        if(class_exists('Wplms_EventOn_Init')){
	    			$shortcode = apply_filters('wplms_batch_events_shortcode','[add_eventon_dv cal_id="'.rand(0,999).'" today="no" show_et_ft_img="no" ft_event_priority="no" wplms_batch="'.$group_id.'"]');
	    			
	    			echo do_shortcode($shortcode).'<style>.eventon_daily_in{margin:0 !important;width:auto!important;}</style>';
	    		}	
        }

        function batch_schedule(){
        	$group_id = bp_get_group_id();
        	?>
        	<div id="batch_schedule"></div>
        	<script>
        	jQuery(document).ready(function($){
        		$('a[href="#schedule"').on('shown.bs.tab', function (e) {
	        		$("#batch_schedule").fullCalendar({
						header: {
							left: 'prev,next today',
							center: 'title',
							right: 'month,agendaWeek,agendaDay'
						},
						eventLimit: true, // allow "more" link when too many events
						editable: false,
						//events:[{title:"Software Training",start:'2016-04-01',end:'2016-04-11'}],
						eventSources: [{
								url : ajaxurl,
								data : {
									action:'fetch_schedule',
									security:$('#batch_security').val(),
									batch_id:<?php echo $group_id; ?>
								},
								ignoreTimezone: true,
								allDayDefault: false
						}],
						loading: function(bool) {},
						eventRender: function(event, element) {},
						viewRender: function(view) {}
					});
				});
        	});
        	</script>
        	<?php 
        }

        function wplms_batch_schedule(){
        	$batch_id= $_REQUEST['batch_id'];
        	
	        if ( !isset($_REQUEST['security']) || !wp_verify_nonce($_REQUEST['security'],'wplms_batches') || !is_numeric($batch_id)){
	           _e('Security check Failed. Contact Administrator.','vibe');
	           die();
	        }

        	$course_ids = get_batch_courses($batch_id);
	        if(empty($course_ids))
	        	return '';

	        $start_time = strtotime($_REQUEST['start']);
	        $end_time = strtotime($_REQUEST['end']);

	       
	        $enable_batch_date = groups_get_groupmeta($batch_id,'enable_batch_date');
	        if(!empty($enable_batch_date)){
	        	$start_batch_date = groups_get_groupmeta($batch_id,'start_batch_date');
	        	$end_batch_date = groups_get_groupmeta($batch_id,'end_batch_date');
	        	$base_time = strtotime($start_batch_date);
	        	if($base_time > $start_time){
	        		$start_time = $base_time;
	        	}
	        	$end_base_time = strtotime($end_batch_date);
	        	if($end_base_time < $end_time){
	        		$end_time = $end_base_time;
	        	}
	        }

        	$batch_start_time = groups_get_groupmeta($batch_id,'batch_start_time');
			$batch_end_time = groups_get_groupmeta($batch_id,'batch_end_time');
			$batch_repeatable = groups_get_groupmeta($batch_id,'batch_repeatable');
			$batch_repeatable_parameter = groups_get_groupmeta($batch_id,'batch_repeatable_parameter');


			$enable_off_schedule = groups_get_groupmeta($batch_id,'enable_off_schedule');

			if(!empty($enable_off_schedule)){
				$weekly_off_schedule = groups_get_groupmeta($batch_id,'weekly_off_schedule');
				$monthly_off_schedule = groups_get_groupmeta($batch_id,'monthly_off_schedule');
				$annual_off_schedule = groups_get_groupmeta($batch_id,'annual_off_schedule');
			}
        

			$course_timings = array();
			$colors = array('#35ABDF','#EF5B34','#71BF7D','#FDA32F','#37BBC6','#FAC039','#57977A');
			foreach($course_ids as $course_id){

				$r = array_rand($colors,1);
				$course_timing=array(
					'title'=>	get_the_title($course_id),	
					'backgroundColor'=> $colors[$r],
					'borderColor'=> $colors[$r],
				);
				
				unset($colors[$r]);
				if(empty($batch_repeatable[$course_id])){
					$course_timing['start'] = date('Y-m-d',$start_time).'T'.$batch_start_time[$course_id];
					$course_timing['end'] = date('Y-m-d',$end_time).'T'.$batch_end_time[$course_id];
					array_push($course_timings, $course_timing);
				}

				if(!empty($batch_repeatable[$course_id])){

					switch($batch_repeatable_parameter[$course_id]){
						case 'day':
						for($repeat_start_time = $start_time;$repeat_start_time<=$end_time;$repeat_start_time = $repeat_start_time+$batch_repeatable[$course_id]*DAY_IN_SECONDS){
							
							$skip=0;
							if(!empty($weekly_off_schedule)){
								$dow = date("N", $repeat_start_time);	

								if(in_array($dow,$weekly_off_schedule)){
									$skip = 1;
								}
							}

							if(!empty($monthly_off_schedule)){
								$dom=date("j",$repeat_start_time);
								if(in_array($dom,$monthly_off_schedule)){
									$skip = 1;
								}
							}

							if(!empty($annual_off_schedule)){
								$dom=date("j",$repeat_start_time);
								$moy=date("F",$repeat_start_time);

								if(in_array($dom.'-'.$moy,$annual_off_schedule)){
									$skip = 1;
								}
							}

							if(empty($skip)){
								$course_timing['start'] =  date('Y-m-d',$repeat_start_time).'T'.$batch_start_time[$course_id];
								$course_timing['end'] = date('Y-m-d',$repeat_start_time).'T'.$batch_end_time[$course_id];
								array_push($course_timings, $course_timing);
							}
						}
						break;
						case 'week':
							for($repeat_start_time=$start_time;$repeat_start_time<=$end_time;$repeat_start_time = $repeat_start_time+$batch_repeatable[$course_id]*WEEK_IN_SECONDS){
								$skip=0;
								if(!empty($weekly_off_schedule)){
									$dow = date("N", $repeat_start_time);	
									if(in_array($dow,$weekly_off_schedule)){
										$skip = 1;
									}
								}

								if(!empty($monthly_off_schedule)){
									$dom=date("j",$repeat_start_time);
									if(in_array($dom,$monthly_off_schedule)){
										$skip = 1;
									}
								}

								if(!empty($annual_off_schedule)){
									$dom=date("j",$repeat_start_time);
									$moy=date("F",$repeat_start_time);

									if(in_array($dom.'-'.$moy,$annual_off_schedule)){
										$skip = 1;
									}
								}

								if(empty($skip)){
									$course_timing['start'] =  date('Y-m-d',$repeat_start_time).'T'.$batch_start_time[$course_id];
									$course_timing['end'] = date('Y-m-d',$repeat_start_time).'T'.$batch_end_time[$course_id];
									array_push($course_timings, $course_timing);
								}
							}
						break;
						case 'month':
							for($repeat_start_time = $start_time;$repeat_start_time<=$end_time;$repeat_start_time = $repeat_start_time+$batch_repeatable[$course_id]*MONTH_IN_SECONDS){
								$skip=0;
								if(!empty($weekly_off_schedule)){
									$dow = date("N", $repeat_start_time);	
									if(in_array($dow,$weekly_off_schedule)){
										$skip = 1;
									}
								}

								if(!empty($monthly_off_schedule)){
									$dom=date("j",$repeat_start_time);
									if(in_array($dom,$monthly_off_schedule)){
										$skip = 1;
									}
								}

								if(!empty($annual_off_schedule)){
									$dom=date("j",$repeat_start_time);
									$moy=date("F",$repeat_start_time);

									if(in_array($dom.'-'.$moy,$annual_off_schedule)){
										$skip = 1;
									}
								}

								if(empty($skip)){
									$course_timing['start'] =  date('Y-m-d',$repeat_start_time).'T'.$batch_start_time[$course_id];
									$course_timing['end'] = date('Y-m-d',$repeat_start_time).'T'.$batch_end_time[$course_id];
									array_push($course_timings, $course_timing);
								}
							}
						break;
						case 'year':
							for($repeat_start_time = $start_time;$repeat_start_time<=$end_time;$repeat_start_time = $repeat_start_time+$batch_repeatable[$course_id]*YEAR_IN_SECONDS){
								$skip=0;
								if(!empty($weekly_off_schedule)){
									$dow = date("N", $repeat_start_time);	
									if(in_array($dow,$weekly_off_schedule)){
										$skip = 1;
									}
								}

								if(!empty($monthly_off_schedule)){
									$dom=date("j",$repeat_start_time);
									if(in_array($dom,$monthly_off_schedule)){
										$skip = 1;
									}
								}

								if(!empty($annual_off_schedule)){
									$dom=date("j",$repeat_start_time);
									$moy=date("F",$repeat_start_time);

									if(in_array($dom.'-'.$moy,$annual_off_schedule)){
										$skip = 1;
									}
								}

								if(empty($skip)){
									$course_timing['start'] =  date('Y-m-d',$repeat_start_time).'T'.$batch_start_time[$course_id];
									$course_timing['end'] = date('Y-m-d',$repeat_start_time).'T'.$batch_end_time[$course_id];
									array_push($course_timings, $course_timing);
								}
							}
						break;
					}//end switch
				}//end repeatable
				
			}
			print_r(json_encode($course_timings));
			die();
        }



        function wplms_events($args,$filters,$ecv = null){
	    	if(!empty($ecv['wplms_batch'])){
	    			$args['meta_query'][]=array(
		    			'key' => 'wplms_ev_batch',
		    			'value'=> $ecv['wplms_batch'],
		    			'compare'=> '=',
		    			);
	    	}
	    	return $args;
	    }
	    
	    function wplms_hidden_batch_element($content,$ecv  = null){
	    	if(!empty($ecv['wplms_batch'])){
    			echo '<span class="evo-data" data-batch="'.$ecv['wplms_batch'].'"></span>';
	    	}
	    }

	    function wplms_ajax_events($args,$filters){
	    	$evodata = $_POST['evodata'];

	    	if(!empty($evodata['batch'])){
	    		
				if(is_numeric($evodata['batch']))
    				$args['meta_query'][]=array(
		    			'key' => 'wplms_ev_batch',
		    			'value'=> $evodata['batch'],
		    			'compare'=> '=',
	    			);
			}
	    	return $args;
	    }

        function batch_email(){
        	/* Use this function to display the actual content of your group extension when the nav item is selected */
			global $wpdb, $bp;

		    $url = untrailingslashit( bp_get_group_permalink( $bp->groups->current_group ) ) . '/'.WPLMS_BATCH_SLUG.'/';

		    $email_capabilities = $this->bp_group_email_get_capabilities();

		    //don't display widget if no capabilities
		    if (!$email_capabilities) {
		      bp_core_add_message( __("You don't have permission to send emails", 'wplms-batches'), 'error' );
		      do_action( 'template_notices' );
		      return false;
		    }

		    $email_success = $this->bp_group_email_send();

		    if (!$email_success) {
		      $email_subject = strip_tags(stripslashes(trim(@$_POST['email_subject'])));
		      $email_text = strip_tags(stripslashes(trim(@$_POST['email_text'])));
		    } else {
					$email_subject = '';
		      		$email_text = '';
				}

		    do_action( 'template_notices' );
		    ?>
		    <div class="bp-widget">
		  		<h4><?php _e('Send Email to Batch Students', 'wplms-batches'); ?></h4>

		      <form action="<?php echo $url; ?>" name="add-email-form" id="add-email-form" class="standard-form" method="post" enctype="multipart/form-data">
		  			<label for="email_subject"><?php _e('Subject', 'wplms-batches'); ?> *</label>
		  			<input name="email_subject" id="email_subject" value="<?php echo $email_subject; ?>" type="text">

		  			<label for="email_text"><?php _e('Email Text', 'wplms-batches'); ?> *
		        <small><?php _e('(No HTML Allowed)', 'wplms-batches'); ?></small></p>
		        </label>
		  			<textarea name="email_text" id="email_text" rows="10"><?php echo $email_text; ?></textarea>

		        <input name="send_email" value="1" type="hidden">
		        <?php wp_nonce_field('wplms_batch_email'); ?>

		  			<p><input value="<?php _e('Send Email', 'wplms-batches'); ?> &raquo;" id="save" name="save" type="submit">
		  			<small><?php _e('Note: This may take a while depending on the size of the batch', 'wplms-batches'); ?></small></p>
		  	 </form>

		    </div>
		    <?php
        }

        function bp_group_email_get_capabilities() {
		    //check if user is admin or moderator
		    if ( bp_group_is_admin() || bp_group_is_mod() ) {
		      return true;
		    } else {
		      return false;
		    }
		}



		function bp_group_email_send() {
		    global $wpdb, $current_user, $bp;

		    $email_capabilities = $this->bp_group_email_get_capabilities();

		    if (isset($_POST['send_email'])) {
		      if (!wp_verify_nonce($_REQUEST['_wpnonce'], 'wplms_batch_email')) {
		        bp_core_add_message( __('There was a security problem', 'wplms-batches'), 'error' );
		        return false;
		      }

		      //reject unqualified users
		      if (!$email_capabilities) {
		        bp_core_add_message( __("You don't have permission to send emails", 'wplms-batches'), 'error' );
		        return false;
		      }

		      //prepare fields
		      $email_subject = strip_tags(stripslashes(trim($_POST['email_subject'])));

		      //check that required title isset after filtering
		      if (empty($email_subject)) {
		        bp_core_add_message( __("A subject is required", 'wplms-batches'), 'error' );
		        return false;
		      }

		      $email_text = strip_tags(stripslashes(trim($_POST['email_text'])));

		      //check that required title isset after filtering
		      if (empty($email_text)) {
		        bp_core_add_message( __("Email text is required", 'wplms-batches'), 'error' );
		        return false;
		      }

		      //send emails
		      $group_link = bp_get_group_permalink( $bp->groups->current_group ) . '/';

		      $user_ids = BP_Groups_Member::get_group_member_ids($bp->groups->current_group->id);

		      $email_count = 0;
		    	foreach ($user_ids as $user_id) {
		    	  //skip opt-outs
		    		if ( 'no' == get_user_meta( $user_id, 'notification_groups_email_send', true ) ) continue;

		    		$ud = get_userdata( $user_id );

		    		// Set up and send the message
		    		$to = $ud->user_email;

		    		$group_link = site_url( $bp->groups->slug . '/' . $bp->groups->current_group->slug . '/' );
		    		$settings_link = bp_core_get_user_domain( $user_id ) . 'settings/notifications/';

		    		$message = sprintf( __(
		  '%s


		  Sent by %s from the "%s" group: %s

		  ---------------------
		  ', 'wplms-batches' ), $email_text, get_blog_option( BP_ROOT_BLOG, 'blogname' ), stripslashes( esc_attr( $bp->groups->current_group->name ) ), $group_link );

		    		$message .= sprintf( __( 'To unsubscribe from these emails please log in and go to: %s', 'wplms-batches' ), $settings_link );

		    		// Send it
		    		wp_mail( $to, $email_subject, $message );

		    		unset( $message, $to );
		    		$email_count++;
		    	}

		      //show success message
		      if ($email_count) {
		        bp_core_add_message( sprintf( __("The email was successfully sent to %d group members", 'wplms-batches'), $email_count) );
		        return true;
		      }
		    } else {
		      return false;
		    }
		  }
    }

add_action( 'bp_init','wplms_batches_register_group_extension'); 
function wplms_batches_register_group_extension(){ 
	bp_register_group_extension( 'BP_Group_Course_Batches' );
}
endif;



