<?php
/**
 * Create WPLMS Batches
 *
 * @class       Wplms_Batches_Init
 * @author      VibeThemes
 * @category    Admin
 * @package     WPLMS-Batches/includes
 * @version     1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}



class Wplms_Batches_Create{


	public static $instance;
	
	public static function init(){

        if ( is_null( self::$instance ) )
            self::$instance = new Wplms_Batches_Create();
        return self::$instance;
    }

	private function __construct(){
		add_filter('wplms_course_creation_tabs',array($this,'add_batches'));
		add_action('wplms_front_end_generate_fields_default',array($this,'create_batches'),10,2);
		add_action('wp_ajax_create_batch',array($this,'create_batch'));
		add_action('wp_ajax_remove_batch_from_course',array($this,'remove_batch_from_course'));
		add_action('wp_ajax_add_batch_to_course',array($this,'add_batch_to_course'));
	}


	function add_batches($fields){ 
		$batches = array(
							'label'=> __('Course Batches','wplms-batches' ),
							'text'=>__('Create/Connect Course Batches','wplms-batches' ),
							'type'=> 'course_batch',
							'style'=>'',
							'id' => 'vibe_batches',
							'from'=> 'meta',
							'desc'=> __('Connect course batches.','wplms-batches' ),
							);
		foreach($fields['course_components']['fields'] as $key => $setting){
			$settings[] = $setting;
			if($key == 1){
				$settings[] = $batches;
			}
		}
		$fields['course_components']['fields'] = $settings;
		return $fields;
	}

	function create_batches($field,$course_id = null){
		if($field['type'] != 'course_batch')
			return;

		echo '<div class="field_wrapper">';
		echo '<label>'. __('Course Batches','wplms-batches').'<a class="tip" title="'.__('Create/Manage batches for this course.').'"><i class="icon-question"></i></a>'.'</label>';

		
		?>
		<?php
		
		if(!empty($course_id)){

			global $wpdb,$bp;
		
			$batches = wplms_get_course_batches($course_id);

			if(!empty($batches) && is_array($batches)){
				echo '<ul class="course_batches">';
				foreach($batches as $batch_id){
					$group = groups_get_group( array(
						'group_id'          => $batch_id,
						'populate_extras'   => false,
						'update_meta_cache' => false,
					) );
					$link  = bp_get_group_permalink( $group );
					/*$moderators = groups_get_group_mods( $group->id );
					$admins = groups_get_group_admins( $group->id );

					$batch_seats = groups_get_groupmeta($batch,'batch_seats');
					$start_batch_date = groups_get_groupmeta($batch,'start_batch_date');
					$end_batch_date = groups_get_groupmeta($batch,'end_batch_date');*/
					echo '<li class="course_batch" data-id="'.$batch_id.'"><strong class="title"><i class="icon-clipboard"></i> '.$group->name.'</strong>
	                                <ul class="data_links">
	                                    <li><a href="'.$link.'" target="_blank" title="'.__('View/Edit Event','wplms-batches' ).'"><span class="dashicons dashicons-edit"></span></a></li>
	                                    <li><a class="remove_batch"><span class="dashicons dashicons-no-alt"></span></a></li>
	                                </ul></li>';
				}
				echo '</ul>';
			}else{
					echo '<ul class="course_batches">';
					echo '</ul>';
				}
		
		}
		?>
		<ul id="batch_hidden_base" style="display:none;">
            <li class="new_batch course_batch">
            	<div id="add_batch" class="row">
					<div class="col-md-6">
						<a class="more"><i class="icon-users"></i> <?php _e('Select Existing batch','wplms-batches' ); ?></a>
						<div class="select_batch_form">
							<select class="addselectbatch" data-placeholder="<?php _e('Select a batch','wplms-batches' ); ?>">
							</select>
							<a class="add_new_batch button"><?php _e('Add as Batch','wplms-batches' ); ?></a>
						</div>
					</div>
					<div class="col-md-6">
						<a class="more"><i class="icon-user"></i> <?php _e('Create New Batch','wplms-batches' ); ?></a>
						<div class="new_batch_form">
							<input type="text" class="form_field" id="vibe_batch_name" name="name" placeholder="<?php _e('Batch Name','wplms-batches' ); ?>">
							<select id="vibe_batch_privacy" class="form_field">
								<option value="public"><?php _e('Public','wplms-batches' ); ?></option>
								<option value="private"><?php _e('Private','wplms-batches' ); ?></option>
								<option value="hidden"><?php _e('Hidden','wplms-batches' ); ?></option>
							</select>
							<textarea class="description" id="vibe_batch_description" placeholder="<?php _e('Batch Description','wplms-batches' ); ?>"></textarea>
							<a class="button small" id="create_new_batch"><?php _e('Create New Batch','wplms-batches' ); ?></a>
						</div>
					</div>
				</div>
				<a class="rem"><i class="icon-x"></i></a>
            </li>
        </ul>
		<div class="add_element">
			<a id="add_course_batch" class="button primary"><?php _e('Add Course Batch','wplms-batches' ); ?></a>
        </div>
        <style>
        .add_element{padding: 60px 0;text-align: center;border: 5px dashed #eee;}.more{background:#fff;}.course_batches{border: 1px solid #EEE;margin-bottom: 30px;}.new_batch{position: relative;}
        #add_course_batch{opacity:0;transition: all 0.2s ease-in;} .add_element:hover #add_course_batch{opacity:1;}
        .course_batch{padding: 15px; background: #fafafa;}.new_batch .rem{position: absolute;right: 10px;top: 10px;}
        ul.data_links{margin-left:20px;opacity:0;display: inline-block;float:right;transition: all 0.2s ease-in-out;}
		ul.data_links>li{float:left;list-style:none;margin-left:5px;}
		ul.data_links>li span{font-size:12px;color:#999;cursor:pointer;}
		.course_batches li:hover .data_links{opacity:1;}.existing_batch{padding: 15px; background: #fafafa;}
		</style>
		<script>
		jQuery(document).ready(function($){
			$('#add_course_batch').unbind('click');
            $('#add_course_batch').on('click',function(){
        		var clone = $('#batch_hidden_base .new_batch').clone();
        		clone.find('.addselectbatch').addClass('selectbatch');
		        $('ul.course_batches').append(clone);
		        $('.course_batches').trigger('active');
		        return false;
    		});
    		$('.course_batches .remove_batch').on('click',function(event){
				event.preventDefault();
				var $this = $(this);
				$.ajax({
	                    type: "POST",
	                    url: ajaxurl,
	                    data: { action: 'remove_batch_from_course', 
	                            security: $('#security').val(),
	                            course_id: $('#course_id').val(),
	                            id: $this.closest('.course_batch').attr('data-id'),
	                          },
	                    cache: false,
	                    success: function (html) {
	                    	if($.isNumeric(html)){
	                        	$this.closest('.course_batch').remove();
	                        }
	                    }
	            });
			});
			$('.course_batches').on('active',function(){
				$('.add_new_batch').on('click',function(){
					var $this = $(this);
					$.ajax({
		                    type: "POST",
		                    url: ajaxurl,
		                    data: { action: 'add_batch_to_course', 
		                            security: $('#security').val(),
		                            course_id: $('#course_id').val(),
		                            id: $('.selectbatch').val(),
		                          },
		                    cache: false,
		                    success: function (html) {
		                    	$this.closest('.new_batch').html(html);
		                    }
		            });
				});
				$('.new_batch .rem').click(function(event){event.preventDefault(); $(this).closest('.new_batch').remove();});
				$('.course_batches .remove_batch').on('click',function(event){
					event.preventDefault();
					var $this = $(this);
					$.ajax({
		                    type: "POST",
		                    url: ajaxurl,
		                    data: { action: 'remove_batch_from_course', 
		                            security: $('#security').val(),
		                            course_id: $('#course_id').val(),
		                            id: $this.closest('.course_batch').attr('data-id'),
		                          },
		                    cache: false,
		                    success: function (html) {
		                    	if($.isNumeric(html)){
		                        	$(this).closest('.course_batch').remove();
		                        }
		                    }
		            });
				});

				$('.new_batch .more').unbind('click');
		        $('.new_batch .more').click(function(event){
		            $('.select_batch_form,.new_batch_form').hide();
		            $(this).next().toggle(200);
		        });
				$('.selectbatch').each(function(){
					var $this = $(this);
					if(!$this.hasClass('select2-hidden-accessible')){
						//$this.select2('remove'); 
					
					$this.select2({
				        minimumInputLength: 4,
				        placeholder: $(this).attr('data-placeholder'),
				        closeOnSelect: true,
				        allowClear: true,
				        ajax: {
				            url: ajaxurl,
				            type: "POST",
				            dataType: 'json',
				            delay: 250,
				            data: function(term){ 
				                    return  {   action: 'get_front_groups', 
				                                security: $('#security').val(),
				                                q: term,
				                            }
				            },
				            processResults: function (data) {
				                return {
				                    results: data
				                };
				            },       
				            cache:true  
				        },
				    });
					}
				});
			
				$('#create_new_batch').on('click',function(){
			        var $this = $(this);
			        var defaulttxt = $this.text();
			        if($this.hasClass('disabled'))
			            return;

			        $this.addClass('disabled');
			        $.confirm({
			          text: wplms_front_end_messages.create_group_confirm,
			          confirm: function() {
			             $.ajax({
			                    type: "POST",
			                    url: ajaxurl,
			                    data: { action: 'create_batch', 
			                            security: $('#security').val(),
			                            course_id: $('#course_id').val(),
			                            title: $('#vibe_batch_name').val(),
			                            privacy:$('#vibe_batch_privacy').val(),
			                            description : $('#vibe_batch_description').val(),
			                          },
			                    cache: false,
			                    success: function (html) {
			                        $this.removeClass('disabled');
			                        $this.closest('.new_batch').html(html);
			                        $('.data_links .remove').click(function(){
			                        	$(this).closest('.new_batch').remove();
			                        });
			                    }
			            });
			          },
			          cancel: function() {
			              $this.removeClass('disabled');
			          },
			          confirmButton: wplms_front_end_messages.create_group_confirm_button,
			          cancelButton: vibe_course_module_strings.cancel
			      });
			    });
			});
		});	
		</script>
       <?php
		echo   '</div>';
	}


	function create_batch(){
        $user_id = get_current_user_id();

        if ( !isset($_POST['security']) || !wp_verify_nonce($_POST['security'],'security') || !current_user_can('edit_posts')){
             _e('Security check Failed. Contact Administrator.','wplms-batches');
             die();
        } 

        $course_id = $_POST['course_id'];
        $group_settings = array(
            'creator_id' => $user_id,
            'name' => $_POST['title'],
            'description' => $_POST['description'],
            'status' => $_POST['privacy'],
            'date_created' => current_time('mysql')
        );

        $group_settings = apply_filters('wplms_front_end_group_vars',$group_settings);
        if($course_setting['vibe_forum'] == 'add_group_forum'){
            $group_settings['enable_forum'] = 1;
        }
        
        
        global $bp;

        $new_group_id = groups_create_group( $group_settings);

        if(is_numeric($new_group_id)){
            groups_update_groupmeta( $new_group_id, 'total_member_count', 1 );
            groups_update_groupmeta( $new_group_id, 'last_activity', gmdate( "Y-m-d H:i:s" ) );
            
            groups_update_groupmeta( $new_group_id, 'course_batch',1);
			groups_add_groupmeta($new_group_id,'batch_course',$course_id);
			$group = groups_get_group( array('group_id' => $new_group_id,'populate_extras'   => false,'update_meta_cache' => false) );
			$link  = bp_get_group_permalink( $group );

            echo '<strong class="title" data-id="'.$new_group_id.'"><i class="icon-clipboard"></i> '.$group->name.'</strong>
	                                <ul class="data_links">
	                                    <li><a href="'.$link.'" target="_blank" title="'.__('View/Edit Event','wplms-batches' ).'"><span class="dashicons dashicons-edit"></span></a></li>
	                                    <li><a class="remove_batch"><span class="dashicons dashicons-no-alt"></i></span></a></li>
	                                </ul>';    
        }else{
            print_r($new_group_id);
        }
        die();
    
	}

	function remove_batch_from_course(){
		$user_id = get_current_user_id();

        if ( !isset($_POST['security']) || !wp_verify_nonce($_POST['security'],'security') || !current_user_can('edit_posts')){
             _e('Security check Failed. Contact Administrator.','wplms-batches');
             die();
        } 

        $course_id = $_POST['course_id'];
        $group_id = $_POST['id'];
        groups_delete_groupmeta( $group_id, 'batch_course',$course_id);
        $courses = groups_get_groupmeta( $group_id, 'batch_course',false);
        if(empty($courses)){ // No longer a Batch
        	groups_delete_groupmeta( $group_id, 'course_batch');
        }
        echo 1;
        die();
	}

	function add_batch_to_course(){
		$user_id = get_current_user_id();

        if ( !isset($_POST['security']) || !wp_verify_nonce($_POST['security'],'security') || !current_user_can('edit_posts')){
             _e('Security check Failed. Contact Administrator.','wplms-batches');
             die();
        } 

        $course_id = $_POST['course_id'];
        $group_id = $_POST['id'];
        groups_update_groupmeta( $group_id, 'course_batch',1);
        groups_add_groupmeta( $group_id, 'batch_course',$course_id);
        $group = groups_get_group( array(
						'group_id'          => $group_id,
						'populate_extras'   => false,
						'update_meta_cache' => false,
					) );
		$link  = bp_get_group_permalink( $group );
        echo '<strong class="title" data-id="'.$new_group_id.'"><i class="icon-clipboard"></i> '.$group->name.'</strong>
                <ul class="data_links">
                    <li><a href="'.$link.'" target="_blank" title="'.__('View/Edit Event','wplms-batches' ).'"><span class="dashicons dashicons-edit"></span></a></li>
                    <li><a class="remove_batch"><span class="dashicons dashicons-no-alt"></i></span></a></li>
                </ul>';

        do_action('wplms_course_batch_added',$group_id,$course_id);        
		die();
	}
}


Wplms_Batches_Create::init();