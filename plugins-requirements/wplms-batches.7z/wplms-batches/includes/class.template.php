<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WPLMS_Batch{


	function __construct($group_id){

		$this->ID = $group_id;
    	$this->enable = groups_get_groupmeta( $group_id, 'course_batch' );
        $this->courses = groups_get_groupmeta($group_id,'batch_course',false);
        $this->batch_course_visibility = groups_get_groupmeta($group_id,'batch_course_visibility');
        $this->enable_batch_duration = groups_get_groupmeta($group_id,'enable_batch_duration');
		$this->batch_duration = groups_get_groupmeta($group_id,'batch_duration');
		$this->batch_duration_parameter = groups_get_groupmeta($group_id,'batch_duration_parameter');

		$this->enable_seats = groups_get_groupmeta($group_id,'enable_seats');
		$this->batch_seats = groups_get_groupmeta($group_id,'batch_seats');
		$this->batch_leaderboard = groups_get_groupmeta($group_id,'batch_leaderboard');
		$this->enable_batch_date = groups_get_groupmeta($group_id,'enable_batch_date');
		$this->start_batch_date = groups_get_groupmeta($group_id,'start_batch_date');
		$this->end_batch_date = groups_get_groupmeta($group_id,'end_batch_date');
		$this->access_within_dates = groups_get_groupmeta($group_id,'access_within_dates');
		
		$this->batch_stats_visibility = groups_get_groupmeta($group_id,'batch_stats_visibility');
		$this->timings = groups_get_groupmeta($group_id,'batch_timings');
		$this->batch_start_time = groups_get_groupmeta($group_id,'batch_start_time');
		$this->batch_end_time = groups_get_groupmeta($group_id,'batch_end_time');
		$this->batch_repeatable = groups_get_groupmeta($group_id,'batch_repeatable');
		$this->batch_repeatable_parameter = groups_get_groupmeta($group_id,'batch_repeatable_parameter');

		$this->enable_off_schedule = groups_get_groupmeta($group_id,'enable_off_schedule');
		$this->weekly_off_schedule = groups_get_groupmeta($group_id,'weekly_off_schedule');
		$this->monthly_off_schedule = groups_get_groupmeta($group_id,'monthly_off_schedule');
		$this->annual_off_schedule = groups_get_groupmeta($group_id,'annual_off_schedule');

		$this->batch_timing_course_accessibility = groups_get_groupmeta($group_id,'batch_timing_course_accessibility');

		$this->batch_events = groups_get_groupmeta($group_id,'batch_events');
		$this->batch_exclusivity = groups_get_groupmeta($group_id,'batch_exclusivity');
	}
}

class WPLMS_Batch_Template{

	protected $batches;
	public static $instance;
	
	public static function init(){

        if ( is_null( self::$instance ) )
            self::$instance = new WPLMS_Batch_Template();
        return self::$instance;
    }

    function __construct($group_id = NULL){

    	global $bp;
    	if(!isset($bp->groups) || !isset($bp->groups->current_group)){
    		return;
    	}

    	
    	if(empty($group_id))
    		$group_id = $bp->groups->current_group->id;

    	if(empty($this->batches)){
    		$this->batches[$group_id] = new WPLMS_Batch($group_id);
    	}

    }

    function get($id=NULL){
    	global $bp;
    	if(!isset($bp->groups) || !isset($bp->groups->current_group)){
    		return;
    	}
    	if(empty($id))
    		$id = $bp->groups->current_group->id;
    	
    	if(empty($this->batches[$id])){
    		$this->batches[$id] = new WPLMS_Batch($id);
    	}
    	return $this->batches[$id];
    }
}

