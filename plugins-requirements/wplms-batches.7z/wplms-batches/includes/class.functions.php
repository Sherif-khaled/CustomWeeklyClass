<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


class WPLMS_Batch_Functions{


	public static $instance;
	
	public static function init(){

        if ( is_null( self::$instance ) )
            self::$instance = new WPLMS_Batch_Functions();
        return self::$instance;
    }

	private function __construct(){
		$this->is_batch = '';
		$this->courses = array();
		$this->user_course_batch_count = array();
		$this->course_batches = array();
		$this->user_batches = array();
		$this->seats = '';
	}

	function is_batch($batch_id){

		if(!empty($this->is_batch)){ // IF already set
			return true;
		}
		$this->is_batch = groups_get_groupmeta($batch_id,'course_batch',true); // Store in Object for repeat use
		if(!empty($this->is_batch))
			return true;

		return false;
	}

	function get_batch_courses($batch_id){
		
		if(!empty($this->courses[$batch_id])){ // IF already set
			return $this->courses[$batch_id];
		}

		$this->courses[$batch_id] = groups_get_groupmeta($batch_id,'batch_course',false);

		if(!empty($this->courses[$batch_id])){
			return $this->courses[$batch_id];
		}
		return 0;
	}

	function user_course_batch_count($user_id,$course_id){

		if(!empty($this->user_course_batch_count[$user_id][$course_id])){
			return $this->user_course_batch_count[$user_id][$course_id];
		}

		global $wpdb,$bp;
		$batches = $wpdb->get_var(
					$wpdb->prepare("SELECT count(gm.group_id)
							FROM {$bp->groups->table_name_members} as g 
							LEFT JOIN {$bp->groups->table_name_groupmeta} as gm
							ON g.group_id = gm.group_id
							WHERE g.user_id = %d 
							AND gm.meta_key = %s 
							AND gm.meta_value = %d",
							$user_id,'batch_course',$course_id));
		$this->user_course_batch_count[$user_id][$course_id] = $batches;
		return $this->user_course_batch_count[$user_id][$course_id];
	}

	function get_user_batches($user_id){

		if(!empty($this->user_batches[$user_id]))
			return $this->user_batches[$user_id];

		global $wpdb,$bp;
		$batches = $wpdb->get_results(
					$wpdb->prepare("SELECT gm.group_id as batch_id
							FROM {$bp->groups->table_name_members} as g 
							LEFT JOIN {$bp->groups->table_name_groupmeta} as gm
							ON g.group_id = gm.group_id
							WHERE g.user_id = %d 
							AND gm.meta_key = %s ",
							$user_id,'course_batch'));
		

		if(!empty($batches)){
			$batch_ids = array();
			foreach($batches as $batch){
				$batch_ids[] = $batch->batch_id;
			}
			$this->user_batches = $batch_ids;
			return $batch_ids;
		}else{
			return false;
		}
	}

	function course_batch_count($course_id){
		if(!empty($this->batch_count[$course_id]))
			return $this->batch_count[$course_id];

		global $wpdb,$bp;
		$this->course_batches[$course_id] = $wpdb->get_results($wpdb->prepare("SELECT group_id FROM {$bp->groups->table_name_groupmeta} WHERE meta_key = %s AND meta_value = %d",'batch_course',$course_id));

		if(empty($this->course_batches))
			$this->batch_count[$course_id] = 0;
		else
			$this->batch_count[$course_id] = count($this->course_batches);
		return $this->batch_count[$course_id];
	}

	function get_course_batches($course_id){

		if(!empty($this->course_batches[$course_id]))
			return $this->course_batches[$course_id];

		global $wpdb,$bp;
		$this->course_batches[$course_id] = $wpdb->get_results($wpdb->prepare("SELECT group_id FROM {$bp->groups->table_name_groupmeta} WHERE meta_key = %s AND meta_value = %d",'batch_course',$course_id));

		return $this->course_batches[$course_id];
	}

	function get_seats($group_id = NULL){
		$group_id = bp_get_group_id();
		if(empty($this->seats)){
			$this->seats = groups_get_groupmeta($group_id,'batch_seats');
			return $this->seats;
		}
		return 0;
	}

	function batch_timing_accessbility($batch_id,$course_id){

		if(!empty($this->acessibility)){
			return $this->acessibility;
		}


		$enable_batch_date	 = groups_get_groupmeta($batch_id,'enable_batch_date');
		if(!empty($enable_batch_date)){

			$access_within_dates = groups_get_groupmeta($batch_id,'access_within_dates');
			if(!empty($access_within_dates)){
				$start_batch_date = groups_get_groupmeta($batch_id,'start_batch_date');
				
				if(!empty($start_batch_date)){
					$start_time = strtotime($start_batch_date);
					if($start_time > current_time('timestamp')){
						$this->acessibility= array('return'=>false,'message'=>sprintf(__('Batch starts in %s','wplms-batches'),human_time_diff($start_time,current_time('timestamp'))));
						return $this->acessibility;
					}

					$end_batch_date = groups_get_groupmeta($batch_id,'end_batch_date');
					if(!empty($end_batch_date)){
						$end_time = strtotime($end_batch_date)+86400;
						if($end_time < current_time('timestamp')){
							$this->acessibility=array('return'=>false,'message'=>__('Course Not Available','wplms-batches'));
							return $this->acessibility;
						}
					}
				}
			}
		}

		$enable_off_schedule = groups_get_groupmeta($batch_id,'enable_off_schedule');
		if(!empty($enable_off_schedule)){

			$weekly_off_schedule = groups_get_groupmeta($batch_id,'weekly_off_schedule');
			if(!empty($weekly_off_schedule)){
				$i = date('N', current_time('timestamp'));
				if(in_array($i, $weekly_off_schedule)){
					$this->acessibility= array('return'=>false,'message'=>__('Course Not Available','wplms-batches'));
					return $this->acessibility;
				}
			}

			$monthly_off_schedule = groups_get_groupmeta($batch_id,'monthly_off_schedule');
			if(!empty($monthly_off_schedule)){
				$i = date('j',current_time('timestamp'));

				if(in_array($i, $monthly_off_schedule)){
					$this->acessibility = array('return'=>false,'message'=>__('Course Not Available','wplms-batches'));
					return $this->acessibility;
				}
			}

			$annual_off_schedule = groups_get_groupmeta($batch_id,'annual_off_schedule');
			if(!empty($annual_off_schedule)){
				$day = date('j',current_time('timestamp'));
				$month = date('n',current_time('timestamp'));
				$check = $month.'-'.$day;
				if(in_array($check,$annual_off_schedule)){
					$this->acessibility=array('return'=>false,'message'=>__('Course Not Available','wplms-batches'));
					return $this->acessibility;
				}
			}
		}

		$timings = groups_get_groupmeta($batch_id,'batch_timings');
		if(!empty($timings)){

			$batch_timing_course_accessibility = groups_get_groupmeta($batch_id,'batch_timing_course_accessibility');
			
			if(!empty($batch_timing_course_accessibility[$course_id])){

				//Check if batch avaialble today.
				$intra_day_timinig_check = 1;
		        if(!empty($enable_batch_date)){
		        	if(empty($start_batch_date)){
		        		$start_batch_date = groups_get_groupmeta($batch_id,'start_batch_date');
		        	}
	        		if(!empty($start_batch_date)){
	        			$intra_day_timinig_check = 0;
						$start_time = strtotime($start_batch_date);
						$batch_repeatable = groups_get_groupmeta($batch_id,'batch_repeatable');
						$batch_repeatable_parameter = groups_get_groupmeta($batch_id,'batch_repeatable_parameter');
						$multiplier = wplms_process_batch_duration($batch_repeatable_parameter[$course_id]);
						
						$repeat_start_time = $start_time;
						
						while($repeat_start_time <= strtotime(date('Y-m-d ')) ){
							if($repeat_start_time == strtotime(date('Y-m-d '))){
								$intra_day_timinig_check = 1;
								break;
							}
							$repeat_start_time = $repeat_start_time+$batch_repeatable[$course_id]*$multiplier;
						}
					}
		        }
		        //End CHECK
		        if($intra_day_timinig_check){
		        	$batch_start_time = groups_get_groupmeta($batch_id,'batch_start_time');
		        	$st = strtotime($batch_start_time[$course_id]);

					if($st > current_time('timestamp')){
						$this->acessibility = array('return'=>false,'message'=>sprintf(__('Batch timing available in %s','wplms-batches'),'<span>'.human_time_diff(current_time('timestamp'),$st).'</span>'));
						return $this->acessibility;
					}

					$batch_end_time = groups_get_groupmeta($batch_id,'batch_end_time');
					$et = strtotime($batch_end_time[$course_id]);
					if($et < current_time('timestamp')){
						$this->acessibility = array('return'=>false,'message'=>sprintf(__('Batch timings over %s ago %s','wplms-batches'),'<span>'.human_time_diff($et,current_time('timestamp')),'</span>'));
						return $this->acessibility;
					}
		        }else{
		        	$this->acessibility =  array('return'=>false,'message'=>__('Course Not Available Today.','wplms-batches'));
		        	return $this->acessibility;
		        }

			}
		}// End timings

		$this->acessibility = array('return'=>true);
		return $this->acessibility;
	}
}


function is_wplms_batch($group_id = NULL){
	if(empty($group_id)){
		$group_id = bp_get_group_id();
		if(empty($group_id))
			return false;
	}
	
	$fx = WPLMS_Batch_Functions::init();
	return $fx->is_batch($group_id);
}


function wplms_get_batch_seats($group_id){
	if(empty($group_id)){
		$group_id = bp_get_group_id();
		if(empty($group_id))
			return false;
	}

	$fx = WPLMS_Batch_Functions::init();
	return $fx->get_seats($group_id);
}


function get_batch_courses($group_id){

	if(empty($group_id)){
		$group_id = bp_get_group_id();
		if(empty($group_id))
			return false;
	}
	$fx = WPLMS_Batch_Functions::init();
	return $fx->get_batch_courses($group_id);
}

function wplms_user_in_course_batches($user_id,$course_id){

	$fx = WPLMS_Batch_Functions::init();
	$count = $fx->user_course_batch_count($user_id,$course_id);
	return (empty($count)?false:true);
}

function wplms_get_user_batches($user_id){
	$fx = WPLMS_Batch_Functions::init();
	return $fx->get_user_batches($user_id);
}

function wplms_course_has_batches($course_id){
	$fx = WPLMS_Batch_Functions::init();
	$batches = $fx->course_batch_count($course_id);
	return (empty($batches)?false:true);
}

function wplms_course_batch_verify($course_id,$group_id){
	global $wpdb,$bp;
	$batches = $wpdb->get_results($wpdb->prepare("SELECT count(group_id) FROM {$bp->groups->table_name_groupmeta} WHERE group_id = %d AND meta_key = %s AND meta_value = %d",$group_id,'batch_course',$course_id));

	return (empty($batches)?false:true);
}

function wplms_get_course_batches($course_id){
	$fx = WPLMS_Batch_Functions::init();
	$batches = $fx->get_course_batches($course_id);
	foreach($batches as $batch){
		$batch_ids[] = $batch->group_id;
	}
	return $batch_ids;
}

function wplms_process_batch_duration($duration = NULL){
	if(empty($duration))
		return 1;

	switch($duration){
		case 'minute':
			return MINUTE_IN_SECONDS;
		break;
		case 'hour':
			return HOUR_IN_SECONDS;
		break;
		case 'day':
			return DAY_IN_SECONDS;
		break;
		case 'week':
			return WEEK_IN_SECONDS;
		break;
		case 'fortnight':
			return WEEK_IN_SECONDS*2;
		break;
		case 'month':
			return MONTH_IN_SECONDS;
		break;
		case 'year':
			return YEAR_IN_SECONDS;
		break;
	}
}


function wplms_batch_timing_accessibility($batch_id,$course_id){
	$fx = WPLMS_Batch_Functions::init();
	return $fx->batch_timing_accessbility($batch_id,$course_id);
}



function wplms_get_batch_link($group_id){
	global $wpdb,$bp;
	$name = $wpdb->get_var($wpdb->prepare("SELECT name FROM {$bp->groups->table_name} WHERE id = %d",$group_id));
	return $name;
}


function wplms_batch_is_user_member( $user_id, $batch_id ){
	global $wpdb,$bp;
	$count = $wpdb->get_var($wpdb->prepare("SELECT count(id) FROM {$bp->groups->table_name_members} WHERE group_id = %d AND user_id = %d",$batch_id,$user_id));
	return (empty($count)?false:true);
}

function wplms_batches_average_rating($group_id){
	$average_rating = groups_get_groupmeta($group_id,'batch_course_average_rating');
	if(empty($average_rating)){
		return __('N.A','wplms-batches');
	}
	return $average_rating;
}

function wplms_batches_get_course_average_rating($group_id){
	$average_rating = groups_get_groupmeta($group_id,'batch_course_average_rating');
	if(empty($average_rating)){
		return __('N.A','wplms-batches');
	}
	return $average_rating;
}