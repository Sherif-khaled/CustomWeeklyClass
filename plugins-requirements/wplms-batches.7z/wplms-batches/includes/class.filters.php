<?php
/**
 * Initialise WPLMS Batches
 *
 * @class       Wplms_Batches_Filters
 * @author      VibeThemes
 * @category    Admin
 * @package     WPLMS-Batches/includes
 * @version     1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


class Wplms_Batches_Filters{


	public static $instance;
	
	public static function init(){

        if ( is_null( self::$instance ) )
            self::$instance = new Wplms_Batches_Filters();
        return self::$instance;
    }

	private function __construct(){
		add_filter('bp_course_get_course_duration',array($this,'batch_duration'),10,3);
		add_filter('bp_course_get_start_date',array($this,'batch_start_date'),10,3);
		add_filter('bp_course_get_max_students',array($this,'batch_max_seats'),10,3);

		//Course button Filters
		add_filter('wplms_start_course_button',array($this,'course_batch_settings'),99,2);
		add_filter('wplms_continue_course_button',array($this,'course_batch_settings'),99,2);
		add_filter('lms_general_settings',array($this,'wplms_batch_course_restriction_switch'));
		add_filter('wplms_carousel_course_filters',array($this,'wplms_batch_courses'));
		add_filter('wplms_grid_course_filters',array($this,'wplms_batch_courses'));
		add_filter('vibe_editor_filterable_type',array($this,'wplms_batch_courses'));
		add_filter('bp_course_wplms_filters',array($this,'wplms_batch_courses'));
		add_filter('bp_course_get_max_students',array($this,'max_students'),10,3);
		add_filter('bp_course_count_students_pursuing',array($this,'students_count'),10,2);
		
		add_filter('bp_groups_user_can_send_invites',array($this,'send_invites'),10,4);
		add_filter('bp_get_group_join_button',array($this,'wplms_batch_join_button'),10,2);

//		$invitable_friends = apply_filters( 'bp_get_new_group_invite_friend_list', $items, $r, $args );

	}

	function wplms_batch_join_button( $button, $group){
		if(!empty($group->is_member)){
			return $button;
		}
		if(is_wplms_batch($group->id)){
			$seats =wplms_get_batch_seats($group->id);
			if(!empty($seats)){
				if($seats <= $group->total_member_count){
					return false;
				}
			}
			
			$batch_exclusivity = groups_get_groupmeta($group->id,'batch_exclusivity');
			if(!empty($batch_exclusivity)){
				return false;
			}
		}
		return $button;
	}

	function max_students($n,$course_id,$user_id){

		if(!empty($this->seat_count[$course_id]))
			return $this->seat_count[$course_id];

		if(wplms_course_has_batches($course_id)){
			
			if(!isset($this->vibe_force_batch_enrolment))
				$this->vibe_force_batch_enrolment = get_post_meta($course_id,'vibe_force_batch_enrolment',true);

			if(vibe_validate($this->vibe_force_batch_enrolment)){

				$batches = wplms_get_course_batches($course_id);	
				if(!empty($batches)){
					$group_ids = implode(',',$batches);
			
					global $bp,$wpdb;
					//Make sure number of seats is enabled in all the course batches
					$enable_seat_batches = $wpdb->get_var("SELECT sum(meta_value) FROM {$bp->groups->table_name_groupmeta} WHERE meta_key = 'enable_seats' AND group_id IN ($group_ids)");

					if($enable_seat_batches == count($batches)){
						$seats = $wpdb->get_var("SELECT sum(meta_value) FROM {$bp->groups->table_name_groupmeta} WHERE meta_key = 'batch_seats' AND group_id IN ($group_ids)");
					}
				
				
					if(!empty($seats)){
						$this->seat_count[$course_id] = $seats;
						$n = $seats;
					}
				}
			}
		}
		return $n;
	}

	function students_count($count,$course_id){
		
		if(wplms_course_has_batches($course_id)){
			
			if(!isset($this->vibe_force_batch_enrolment)){
				$this->vibe_force_batch_enrolment = get_post_meta($course_id,'vibe_force_batch_enrolment',true);
			}
			
			if(vibe_validate($this->vibe_force_batch_enrolment)){
				$batches = wplms_get_course_batches($course_id);	
				if(!empty($batches)){
					$group_ids = implode(',',$batches);
			
					global $bp,$wpdb;
					//Make sure number of seats is enabled in all the course batches
					$enrolled_user_count = $wpdb->get_var("SELECT sum(meta_value) FROM {$bp->groups->table_name_groupmeta} WHERE meta_key = 'total_member_count' AND group_id IN ($group_ids)");
				
					if(!empty($enrolled_user_count))
						return $enrolled_user_count;
				}
			}
		}

		return $count;
	}

	function wplms_batch_course_restriction_switch($settings){
		$settings[] = array(
			'label'=>__('WPLMS Batch Settings','vibe-customtypes' ),
			'type'=> 'heading',
		);
		$settings[] = array(
	            'label' => __('Enable Batch Course Visibility switch', 'vibe-customtypes'),
	            'name' => 'enable_batch_course_visibility_switch',
	            'desc' => __('Enable "BATCH COURSE VISIBILITY" switch in batch settings, enabling "BATCH COURSE VISIBILITY" switch would restrict course visbility for batch students to batch courses', 'vibe-customtypes'),
	            'type' => 'checkbox',
			);
		$settings[] = array(
	            'label' => __('Enable Course auto subscribe for Batch students', 'vibe-customtypes'),
	            'name' => 'enable_batch_course_auto_susbcribe',
	            'desc' => __('Students in Batch are automatically subscribed to Batch courses', 'vibe-customtypes'),
	            'type' => 'checkbox',
			);
		return$settings;
	}

	function wplms_batch_courses($args){

		$visibility_flag = apply_filters('wplms_batches_enable_batch_course_visibility_switch',0);
		if(empty($visibility_flag) || current_user_can('edit_posts'))
			return $args;

	  	if($args['post_type'] == 'course'){

	    	$user_id=get_current_user_id();
	    	
	    	if(isset($args['meta_query']) && is_array($args['meta_query']) && is_user_logged_in()){
	       		foreach($args['meta_query'] as $query){
	         		if(isset($query) && is_array($query)){
	            		if($query['key'] == $user_id){
	              			return $args;
	            		}
	         		}
	       		}
	    	}
	    	
	    	global $wpdb,$bp;
			$batches = $wpdb->get_results(
				$wpdb->prepare("SELECT gm2.meta_value as course_id
						FROM {$bp->groups->table_name_members} as g 
						LEFT JOIN {$bp->groups->table_name_groupmeta} as gm
						ON g.group_id = gm.group_id
						LEFT JOIN {$bp->groups->table_name_groupmeta} as gm2
						ON g.group_id = gm2.group_id
						WHERE g.user_id = %d 
						AND gm.meta_key = %s
						AND gm.meta_value = %d 
						AND gm2.meta_key = %s ",
						$user_id,'batch_course_visibility',1,'batch_course'));

	    	if(empty($batches)){
	    		return $args;
	    	}
	    	$courses = array();
	    	foreach($batches as $batch){
	    		$courses[$batch->course_id]=$batch->course_id;
	    	}

	    	
	      	if(!empty($courses) && is_array($courses) && !isset($args['author'])){
        		if(!empty($args['post__in'])){
	          		$args['post__in'] = array_merge($args['post__in'], $courses);
	        	}else{
	          		$args['post__in'] = $courses;  
	        	}
	      	} 
	  	}
	  	
	  	return $args;    
	}

	function course_batch_settings($html,$course_id){
		$lock = get_post_meta($course_id,'vibe_force_batch_enrolment',true);
		if(!empty($lock) && (function_exists('vibe_validate') && vibe_validate($lock))){
			$user_id = get_current_user_id();
			if(!wplms_user_in_course_batches($user_id,$course_id)){ 
				$html = '<a href="'.get_permalink($course_id).'?error=enroll" class="course_button button full">'.__('Enroll in Batch','wplms-batches').'</a>';
			}
		}
		if(is_user_logged_in()){
			$batches = wplms_get_course_batches($course_id);
			if(!empty($batches)){
				$user_id = get_current_user_ID();
				foreach($batches as $batch_id){
					
					if(wplms_batch_is_user_member( $user_id, $batch_id )){
						$batch_timing_course_accessibility = groups_get_groupmeta($batch_id,'batch_timing_course_accessibility');
						if(!empty($batch_timing_course_accessibility[$course_id])){
							$return = wplms_batch_timing_accessibility($batch_id,$course_id);
							if(!$return['return']){
								$html='<a href="'.get_permalink($course_id).'?error=unavailable&batch='.$batch_id.'&message='.$return['message'].'" class="course_button button full">'.$return['message'].'</a>';
								
							}
							break;
						}
					}
				}
			}
		}

		return $html;
	}

	function batch_duration($flag,$course_id,$user_id){

		if(empty($this->batches[$course_id])){
			$this->batches[$course_id] = wplms_get_course_batches($course_id);
		}
		if(empty($user_id)){
			if(is_user_logged_in())
				$user_id = get_current_user_ID();
			else
				return $flag;
		}

		if(!empty($this->batches[$course_id])){
			foreach($this->batches[$course_id] as $batch_id){
				if(wplms_batch_is_user_member( $user_id, $batch_id )){
					
					$enable = groups_get_groupmeta($batch_id,'enable_batch_duration',true);
					if(!empty($enable)){
						$duration = groups_get_groupmeta($batch_id,'batch_duration',true);
						$parameter = groups_get_groupmeta($batch_id,'batch_duration_parameter',true);
						return $duration*$parameter;
					}
				}
			}
		}
		return $flag;
	}

	function batch_start_date($flag,$course_id,$user_id){

		if(empty($this->batches[$course_id])){
			$this->batches[$course_id] = wplms_get_course_batches($course_id);
		}
		if(empty($user_id)){
			if(is_user_logged_in()){
				$user_id = get_current_user_ID();
			}else{
				return $flag;
			}
		}
		
		if(!empty($this->batches[$course_id])){
			foreach($this->batches[$course_id] as $batch_id){
				if(wplms_batch_is_user_member( $user_id, $batch_id )){
					$enable = groups_get_groupmeta($batch_id,'enable_batch_date');
					if(!empty($enable)){
						$start_date = groups_get_groupmeta($batch_id,'start_batch_date',true);
						return $start_date;
					}
				}
			}
		}
		return $flag;
	}

	function batch_max_seats($flag,$course_id,$user_id=NULL){


		if(empty($this->batches[$course_id])){
			$this->batches[$course_id] = wplms_get_course_batches($course_id);
		}
		
		if(empty($user_id)){
			if(is_user_logged_in())
				$user_id = get_current_user_ID();
			else
				return $flag;
		}

		if(!empty($this->batches[$course_id])){
			foreach($this->batches[$course_id] as $batch_id){
				if(wplms_batch_is_user_member( $user_id, $batch_id )){
					$enable = groups_get_groupmeta($batch_id,'enable_seats',true);
					if(!empty($enable)){
						$seats = groups_get_groupmeta($batch_id,'batch_seats',true);
						return $seats;
					}
				}
			}
		}
		return $flag;
	}

	function send_invites($can_send_invites, $group_id, $invite_status, $user_id){

		/*
		*	Not a Batch Baild out
		*/
		if(!is_wplms_batch($group_id))	
			return $can_send_invites;

		/*
		*	If user is administrator Bail out
		*/
		if(current_user_can('manage_options'))
			return $can_send_invites;			

		/*
		*	Check Current user Permission levels
		*/
		
		if ( groups_is_user_mod( $user_id, $group_id ) || groups_is_user_admin( $user_id, $group_id ) ) {
			$can_send_invites = true;

			$enable = groups_get_groupmeta($group_id,'enable_seats',true);
			if(!empty($enable)){
				$max_seats = groups_get_groupmeta($group_id,'batch_seats',true);
				$seats = groups_get_total_member_count($group_id);
				if($seats >= $max_seats){
					$can_send_invites = false;
				}
			}
		}else{
			$can_send_invites = false;
		}

		return $can_send_invites;	
	}
}

Wplms_Batches_Filters::init();