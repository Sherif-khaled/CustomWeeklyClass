<?php
/*
Plugin Name: WPLMS Batches
Plugin URI: http://www.vibethemes.com/
Description: This plugin extends WPLMS LMS Platform to Support Batches/Classes for Courses
Version: 1.2.1
Author: Mr.Vibe
Author URI: http://www.vibethemes.com/
Text Domain: wplms-batches
Domain Path: /languages/
*/
if ( !defined( 'ABSPATH' ) ) exit; 
/*  Copyright 2016 VibeThemes  (email: vibethemes@gmail.com) */


include_once 'includes/class.updater.php';
include_once 'includes/class.config.php';

$active_components = get_option('bp-active-components');

if(!empty($active_components['groups'])){
    include_once 'includes/class.template.php';
    include_once 'includes/class.admin.php';
    include_once 'includes/class.init.php';
    include_once 'includes/class.functions.php';
    include_once 'includes/class.filters.php';
    include_once 'includes/class.actions.php';
}else{
    add_action('bp_loaded',function(){
        if(function_exists('bp_is_active')){
            if(bp_is_active('groups')){
                add_action('admin_notices', function(){ echo '<div class="update-nag notice"><p>'.sprintf(__('WPLMS Batches requires an active BuddyPress Groups component, %s click here to enable %s','wplms-batches'),'<a href="'.admin_url( 'options-general.php?page=bp-components' ).'">','</a>').'</p></div>';});
            }
        }else{
            //BuddyPress not active !
            add_action('admin_notices', function(){ echo '<div class="update-nag notice"><p>'.__('WPLMS Batches requires BuddyPress to be installed and active.','wplms-batches').'</p></div>';});
        }
    });
}





add_action('plugins_loaded','wplms_batches_translations');
function wplms_batches_translations(){
    $locale = apply_filters("plugin_locale", get_locale(), 'wplms-batches');
    $lang_dir = dirname( __FILE__ ) . '/languages/';
    $mofile        = sprintf( '%1$s-%2$s.mo', 'wplms-batches', $locale );
    $mofile_local  = $lang_dir . $mofile;
    $mofile_global = WP_LANG_DIR . '/plugins/' . $mofile;

    if ( file_exists( $mofile_global ) ) {
        load_textdomain( 'wplms-batches', $mofile_global );
    } else {
        load_textdomain( 'wplms-batches', $mofile_local );
    }  
}


function Wplms_Batches_Plugin_updater() {
    $license_key = trim( get_option( 'wplms_batches_license_key' ) );
    $edd_updater = new Wplms_Batches_Plugin_Updater( 'http://vibethemes.com', __FILE__, array(
            'version'   => '1.2.1',               
            'license'   => $license_key,        
            'item_name' => 'WPLMS Batches',    
            'author'    => 'VibeThemes' 
        )
    );
}
add_action( 'admin_init', 'Wplms_Batches_Plugin_updater', 0 );