jQuery(document).ready(function($){
  
	$('.enroll_in_batch').on('click',function(){
		var $this = $(this);
		var defaulttxt = $this.text();
		if($this.hasClass('disabled'))
			return;

		$('.enroll_in_batch').addClass('disabled');
      	$.confirm({
          	text: wplms_batches.enroll_warning,
          	confirm: function() {
             	$.ajax({
                    type: "POST",
                    url: ajaxurl,
                    data: { action: 'enroll_user_to_course_batch',
                            security: $('#enroll_now'+$this.attr('data-batch')).val(),
                            course_id: $('#batch_course_id').val(),
                            batch:$this.attr('data-batch'),
                          },
                    cache: false,
                    success: function (html) {
                    	if($.isNumeric(parseInt(html))){
                    		$this.remove();
                    		$('#batch'+html+' .labels').append('<span class="enrolled">'+wplms_batches.enrolled+'</span>');
                        setTimeout(function(){location.reload(true);}, 2000);
                    	}else{
                    		$this.text(html);
                    		setTimeout(function(){$this.text(defaulttxt);}, 500);
                    	}
                    	$this.removeClass('disabled');
                    }
            	});
          	},
          	cancel: function() {
          		$('.enroll_in_batch').addClass('disabled');
          	},
          	confirmButton: vibe_course_module_strings.confirm,
          	cancelButton: vibe_course_module_strings.cancel
      	});
	});

	$('.batch_news').flexslider({
		animation: "slide",
    controlNav: false,
    directionNav: true,
    animationLoop: true,
    slideshow: true,
    prevText: "<i class='fa fa-chevron-left'></i>",
    nextText: "<i class='fa fa-chevron-right'></i>",
	});

	$('table#batch_leaderboard').each(function(){
		$(this).DataTable();
	});

	$('.big_dial').each(function(){
	    $(this).knob({
	        'readOnly': true, 
	        'width': 150, 
	        'height': 150, 
	        'fgColor': vibe_course_module_strings.theme_color, 
	        'bgColor': '#f6f6f6',   
	        'thickness': 0.05
	  });
	});

	$('#get_batch_course_stats').on('click',function(){
		var $this = $(this);
		var defaulttxt = $this.text();
		$this.text(wplms_batches.fetching);
		if($this.hasClass('disabled'))
			return;
		
		$this.addClass('disabled');
		$('.course_stats_form').find('#stats').remove();
		$.ajax({
            type: "POST",
            url: ajaxurl,
            data: { action: 'get_batch_course_stats',
                    security: $('#batch_course_security').val(),
                    course_id: $('#batch_course').val(),
                    batch_id:$('#course_batch_id').val(),
                  },
            cache: false,
            success: function (html) {
            	$('.course_stats_form').append('<div id="stats">'+html+'</div>');
            	$('table.course_leaderboard').DataTable();
            	setTimeout(function(){$this.text(defaulttxt);}, 2000);
            	$this.removeClass('disabled');
            }
    	});
	});

	
		
});